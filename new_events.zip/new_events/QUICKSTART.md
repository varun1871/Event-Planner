# ⚡ Quick Start Guide - EventPlanner Pro

Get up and running in 5 minutes!

---

## 🚀 Installation (3 Steps)

### 1️⃣ Import Database
```
1. Open: http://localhost/phpmyadmin
2. Create database: eventplanner
3. Import file: eventplanner.sql
4. Done! ✓
```

### 2️⃣ Start XAMPP
```
1. Open XAMPP Control Panel
2. Start Apache
3. Start MySQL
4. Both should show green "Running"
```

### 3️⃣ Access Application
```
Open browser → http://localhost/new_events/
```

---

## 🔐 Login

### Admin
```
Email: admin@eventplanner.com
Password: admin123
URL: http://localhost/new_events/auth/login.php
```

---

## 🎯 Quick Test

### Test as User:
1. Register new account → http://localhost/new_events/auth/register.php
2. Browse events → Click "Events" in menu
3. View event details → Click any event
4. Add to cart → Click "Add to Cart"
5. Checkout → Complete booking
6. Download ticket → From dashboard

### Test as Organizer:
1. Register as organizer
2. Login as admin
3. Approve organizer → Admin Panel → Manage Organizers
4. Logout and login as organizer
5. Create event → Organizer Panel → Create New Event
6. View bookings → When users book your event

### Test as Admin:
1. Login with admin credentials
2. View dashboard → See statistics
3. Manage users → Activate/deactivate
4. Manage events → Publish/unpublish
5. View logs → Track activities

---

## 📊 Sample Data

### Create Sample Events:
1. Login as organizer
2. Go to: Add Event
3. Fill in:
   - Title: "Summer Music Festival"
   - Category: Music & Concerts
   - City: "New York"
   - Venue: "Central Park"
   - Date: Future date
   - Price: 50.00
   - Seats: 100
   - Images: Use URLs from Unsplash
   - Status: Published

### Sample Image URLs:
```
https://images.unsplash.com/photo-1540039155733-5bb30b53aa14
https://images.unsplash.com/photo-1501281668745-f7f57925c3b4
https://images.unsplash.com/photo-1492684223066-81342ee5ff30
```

---

## 🎨 Features to Try

### ✅ User Features:
- [ ] Search events by keyword
- [ ] Filter by category and city
- [ ] Add events to wishlist
- [ ] Book multiple tickets
- [ ] Download PDF tickets
- [ ] Write reviews
- [ ] View AI recommendations

### ✅ Organizer Features:
- [ ] Create events
- [ ] Edit event details
- [ ] View bookings
- [ ] Export attendee list (CSV)
- [ ] Track revenue
- [ ] View analytics

### ✅ Admin Features:
- [ ] Approve organizers
- [ ] Manage all events
- [ ] View system logs
- [ ] Add categories
- [ ] Update settings
- [ ] View revenue charts

---

## 🤖 AI Recommendations

The AI learns from:
- Your searches
- Events you view
- Wishlist additions
- Booking history

To see recommendations:
1. Browse different event categories
2. Add events to wishlist
3. Book some events
4. Check "Recommended For You" on homepage
5. View "Similar Events" on event details

---

## 🐛 Troubleshooting

### Can't access site?
```
✓ Check Apache is running
✓ URL is: http://localhost/new_events/
✓ Files are in: C:\xampp\htdocs\new_events\
```

### Database error?
```
✓ Check MySQL is running
✓ Database 'eventplanner' exists
✓ SQL file imported successfully
```

### Login not working?
```
✓ Use correct email: admin@eventplanner.com
✓ Use correct password: admin123
✓ Clear browser cookies
```

---

## 📱 Mobile Testing

The site is fully responsive! Test on:
- Desktop (1920x1080)
- Tablet (768x1024)
- Mobile (375x667)

Use browser DevTools (F12) → Toggle device toolbar

---

## 🎯 Next Steps

1. ✅ Read full README.md
2. ✅ Create sample events
3. ✅ Test all features
4. ✅ Customize settings
5. ✅ Add your own categories
6. ✅ Invite users to test

---

## 📚 Documentation

- **README.md** - Full documentation
- **INSTALLATION.md** - Detailed installation
- **QUICKSTART.md** - This file

---

## 🎉 You're Ready!

Your EventPlanner Pro is now running!

**Homepage:** http://localhost/new_events/
**Admin Panel:** http://localhost/new_events/admin/admin_dashboard.php

**Enjoy building amazing events! 🚀**

<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

$booking_id = isset($_GET['booking_id']) ? (int)$_GET['booking_id'] : 0;

// Get booking details
$query = "SELECT b.*, e.title, e.description, e.event_date, e.event_time, e.venue, e.city, 
          e.price, u.name as user_name, u.email as user_email,
          org_user.name as organizer_name
          FROM bookings b
          JOIN events e ON b.event_id = e.id
          JOIN users u ON b.user_id = u.id
          JOIN organizers o ON e.organizer_id = o.id
          JOIN users org_user ON o.user_id = org_user.id
          WHERE b.id = ? AND b.user_id = ?";

$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $booking_id, $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$booking = mysqli_fetch_assoc($result);

if (!$booking) {
    die('Booking not found');
}

// Generate PDF using basic HTML to PDF approach
// Since FPDF requires installation, we'll create a simple HTML ticket that can be printed

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ticket - <?php echo htmlspecialchars($booking['booking_code']); ?></title>
    <style>
        @media print {
            .no-print { display: none; }
        }
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .ticket {
            border: 3px solid #667eea;
            border-radius: 15px;
            padding: 30px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .ticket-header {
            text-align: center;
            border-bottom: 2px dashed #667eea;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .ticket-header h1 {
            color: #667eea;
            margin: 0;
        }
        .barcode {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            letter-spacing: 3px;
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .ticket-info {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin: 15px 0;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: bold;
            color: #667eea;
        }
        .qr-placeholder {
            width: 150px;
            height: 150px;
            background: white;
            border: 2px solid #667eea;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 20px auto;
            border-radius: 8px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px dashed #667eea;
            color: #666;
        }
        .btn-print {
            background: #667eea;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            margin: 20px 0;
        }
        .btn-print:hover {
            background: #5568d3;
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center;">
        <button class="btn-print" onclick="window.print()">🖨️ Print Ticket</button>
        <button class="btn-print" onclick="window.close()">✖️ Close</button>
    </div>
    
    <div class="ticket">
        <div class="ticket-header">
            <h1>🎫 EVENT TICKET</h1>
            <p style="margin: 5px 0; color: #666;">EventPlanner Pro</p>
        </div>
        
        <div class="barcode">
            <?php echo $booking['booking_code']; ?>
        </div>
        
        <div class="ticket-info">
            <h2 style="color: #667eea; margin-top: 0;"><?php echo htmlspecialchars($booking['title']); ?></h2>
            
            <div class="info-row">
                <span class="label">📅 Date:</span>
                <span><?php echo date('l, F j, Y', strtotime($booking['event_date'])); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">🕐 Time:</span>
                <span><?php echo date('h:i A', strtotime($booking['event_time'])); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">📍 Venue:</span>
                <span><?php echo htmlspecialchars($booking['venue']); ?>, <?php echo htmlspecialchars($booking['city']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">👤 Name:</span>
                <span><?php echo htmlspecialchars($booking['user_name']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">📧 Email:</span>
                <span><?php echo htmlspecialchars($booking['user_email']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">🎟️ Tickets:</span>
                <span><?php echo $booking['qty']; ?> x <?php echo format_currency($booking['price']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">💰 Total:</span>
                <span style="font-size: 20px; font-weight: bold; color: #667eea;">
                    <?php echo format_currency($booking['total_price']); ?>
                </span>
            </div>
            
            <div class="info-row">
                <span class="label">🏢 Organizer:</span>
                <span><?php echo htmlspecialchars($booking['organizer_name']); ?></span>
            </div>
            
            <div class="info-row">
                <span class="label">📋 Status:</span>
                <span style="color: #10b981; font-weight: bold;">✓ CONFIRMED</span>
            </div>
        </div>
        
        <div class="qr-placeholder">
            <div style="text-align: center;">
                <div style="font-size: 48px;">📱</div>
                <small>Scan at Entry</small>
            </div>
        </div>
        
        <div class="footer">
            <p><strong>Important Information:</strong></p>
            <p style="font-size: 12px; line-height: 1.6;">
                • Please arrive 30 minutes before the event starts<br>
                • Bring a valid ID for verification<br>
                • This ticket is non-transferable and non-refundable<br>
                • Keep this ticket safe and present it at the venue entrance
            </p>
            <p style="margin-top: 15px; font-size: 11px;">
                Booking Date: <?php echo date('M d, Y h:i A', strtotime($booking['created_at'])); ?><br>
                © <?php echo date('Y'); ?> EventPlanner Pro. All rights reserved.
            </p>
        </div>
    </div>
    
    <script>
        // Auto-print option
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>

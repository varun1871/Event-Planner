<?php
// Add Personal Events Category Script
require_once 'config/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Personal Events Category</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 700px; margin: 50px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; margin-right: 10px; }
        ul { list-style: none; padding-left: 20px; }
        ul li { padding: 5px 0; }
        h4 { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>✨ Add Personal Events Category</h2>
        
        <div class="info">
            <h4>🎉 Personal Events Category Includes:</h4>
            <ul>
                <li>• Birthday Party</li>
                <li>• Wedding</li>
                <li>• Engagement Ceremony</li>
                <li>• Anniversary Celebration</li>
                <li>• Baby Shower</li>
                <li>• Naming Ceremony</li>
                <li>• Housewarming</li>
                <li>• Retirement Party</li>
            </ul>
        </div>
        
        <?php
        $category_name = 'Personal Events';
        $category_icon = 'personal';
        
        // Check if category already exists
        $check = mysqli_prepare($conn, "SELECT id FROM categories WHERE name = ?");
        mysqli_stmt_bind_param($check, "s", $category_name);
        mysqli_stmt_execute($check);
        $result = mysqli_stmt_get_result($check);
        
        if (mysqli_num_rows($result) > 0) {
            echo "<div class='info'>";
            echo "<h3>ℹ️ Category Already Exists</h3>";
            echo "<p><strong>Personal Events</strong> category is already in your database.</p>";
            echo "</div>";
        } else {
            // Insert new category
            $insert = mysqli_prepare($conn, "INSERT INTO categories (name, icon) VALUES (?, ?)");
            mysqli_stmt_bind_param($insert, "ss", $category_name, $category_icon);
            
            if (mysqli_stmt_execute($insert)) {
                echo "<div class='success'>";
                echo "<h3>✓ Success!</h3>";
                echo "<p><strong>Personal Events</strong> category has been added successfully!</p>";
                echo "<p>Organizers can now create events under this category for birthdays, weddings, and other personal celebrations.</p>";
                echo "</div>";
            } else {
                echo "<div class='error'>";
                echo "<h3>✗ Error</h3>";
                echo "<p>Failed to add category: " . mysqli_error($conn) . "</p>";
                echo "</div>";
            }
            mysqli_stmt_close($insert);
        }
        mysqli_stmt_close($check);
        mysqli_close($conn);
        ?>
        
        <a href="index.php" class="btn">Go to Homepage</a>
        <a href="admin/manage_categories.php" class="btn" style="background:#28a745;">Manage Categories</a>
    </div>
</body>
</html>

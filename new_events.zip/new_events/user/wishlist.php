<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

$page_title = 'My Wishlist';
$user_id = $_SESSION['user_id'];

// Get wishlist items
$wishlist_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                   (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                   (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count,
                   w.created_at as added_date
                   FROM wishlist w
                   JOIN events e ON w.event_id = e.id
                   JOIN categories c ON e.category_id = c.id
                   JOIN organizers o ON e.organizer_id = o.id
                   JOIN users u ON o.user_id = u.id
                   WHERE w.user_id = ?
                   ORDER BY w.created_at DESC";
$stmt = mysqli_prepare($conn, $wishlist_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$wishlist_result = mysqli_stmt_get_result($stmt);

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <h2 class="mb-4"><i class="bi bi-heart-fill text-danger"></i> My Wishlist</h2>
    
    <?php if (mysqli_num_rows($wishlist_result) > 0): ?>
        <div class="row g-4">
            <?php while ($event = mysqli_fetch_assoc($wishlist_result)): ?>
            <div class="col-md-6 col-lg-4">
                <?php include '../includes/event_card.php'; ?>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-heart text-muted" style="font-size: 5rem;"></i>
            <h3 class="mt-3">Your Wishlist is Empty</h3>
            <p class="text-muted">Save events you're interested in to your wishlist!</p>
            <a href="../events/events.php" class="btn btn-primary">
                <i class="bi bi-search"></i> Browse Events
            </a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

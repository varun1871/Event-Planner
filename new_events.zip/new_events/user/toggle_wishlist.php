<?php
require_once '../config/db.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = (int)$_POST['event_id'];
    $user_id = $_SESSION['user_id'];
    
    // Check if already in wishlist
    $stmt = mysqli_prepare($conn, "SELECT id FROM wishlist WHERE user_id = ? AND event_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $user_id, $event_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($result) > 0) {
        // Remove from wishlist
        $stmt = mysqli_prepare($conn, "DELETE FROM wishlist WHERE user_id = ? AND event_id = ?");
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $event_id);
        mysqli_stmt_execute($stmt);
        
        echo json_encode(['success' => true, 'action' => 'removed']);
    } else {
        // Add to wishlist
        $stmt = mysqli_prepare($conn, "INSERT INTO wishlist (user_id, event_id) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $event_id);
        mysqli_stmt_execute($stmt);
        
        // Track activity
        $event_query = mysqli_query($conn, "SELECT category_id FROM events WHERE id = $event_id");
        $event_data = mysqli_fetch_assoc($event_query);
        track_user_activity($user_id, 'wishlist', $event_id, $event_data['category_id']);
        
        echo json_encode(['success' => true, 'action' => 'added']);
    }
    
    mysqli_stmt_close($stmt);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>

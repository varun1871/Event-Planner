<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = (int)$_POST['event_id'];
    $rating = (int)$_POST['rating'];
    $comment = clean_input($_POST['comment']);
    $user_id = $_SESSION['user_id'];
    
    // Validate rating
    if ($rating < 1 || $rating > 5) {
        $_SESSION['error_message'] = 'Invalid rating value.';
        redirect('../events/event_detail.php?id=' . $event_id);
    }
    
    // Check if user has booked this event
    $stmt = mysqli_prepare($conn, "SELECT id FROM bookings WHERE user_id = ? AND event_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $user_id, $event_id);
    mysqli_stmt_execute($stmt);
    
    if (mysqli_stmt_get_result($stmt)->num_rows === 0) {
        $_SESSION['error_message'] = 'You can only review events you have booked.';
        redirect('../events/event_detail.php?id=' . $event_id);
    }
    
    // Check if already reviewed
    $stmt = mysqli_prepare($conn, "SELECT id FROM reviews WHERE user_id = ? AND event_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $user_id, $event_id);
    mysqli_stmt_execute($stmt);
    
    if (mysqli_stmt_get_result($stmt)->num_rows > 0) {
        $_SESSION['error_message'] = 'You have already reviewed this event.';
        redirect('../events/event_detail.php?id=' . $event_id);
    }
    
    // Insert review
    $stmt = mysqli_prepare($conn, "INSERT INTO reviews (user_id, event_id, rating, comment) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "iiis", $user_id, $event_id, $rating, $comment);
    
    if (mysqli_stmt_execute($stmt)) {
        // Update event scores
        update_event_scores($event_id);
        
        log_activity($user_id, 'Review Submitted', "Reviewed event ID: $event_id");
        $_SESSION['success_message'] = 'Thank you for your review!';
    } else {
        $_SESSION['error_message'] = 'Failed to submit review.';
    }
    
    mysqli_stmt_close($stmt);
}

redirect('../events/event_detail.php?id=' . $event_id);
?>

<?php
require_once '../config/db.php';
require_once '../includes/ai_engine.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

$page_title = 'Dashboard';
$user_id = $_SESSION['user_id'];

// Get user stats
$bookings_query = "SELECT COUNT(*) as total FROM bookings WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $bookings_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$total_bookings = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

$wishlist_query = "SELECT COUNT(*) as total FROM wishlist WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $wishlist_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$total_wishlist = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

$spent_query = "SELECT SUM(total_price) as total FROM bookings WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $spent_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$total_spent = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] ?? 0;

// Get upcoming bookings
$upcoming_query = "SELECT b.*, e.title, e.event_date, e.event_time, e.venue, e.city, e.images
                   FROM bookings b
                   JOIN events e ON b.event_id = e.id
                   WHERE b.user_id = ? AND e.event_date >= CURDATE()
                   ORDER BY e.event_date ASC
                   LIMIT 5";
$stmt = mysqli_prepare($conn, $upcoming_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$upcoming_result = mysqli_stmt_get_result($stmt);

// Get AI recommendations
$recommended_events = get_ai_recommendations($user_id, 3);

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <div class="row mb-4">
        <div class="col">
            <h2>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! 👋</h2>
            <p class="text-muted">Here's what's happening with your events</p>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card dashboard-card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Bookings</h6>
                            <h2 class="mb-0"><?php echo $total_bookings; ?></h2>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded">
                            <i class="bi bi-ticket-perforated text-primary fs-1"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card dashboard-card warning shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Wishlist Items</h6>
                            <h2 class="mb-0"><?php echo $total_wishlist; ?></h2>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded">
                            <i class="bi bi-heart text-warning fs-1"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card dashboard-card success shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Spent</h6>
                            <h2 class="mb-0"><?php echo format_currency($total_spent); ?></h2>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded">
                            <i class="bi bi-currency-dollar text-success fs-1"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Upcoming Events -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="bi bi-calendar-check"></i> Upcoming Events</h5>
                        <a href="bookings.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (mysqli_num_rows($upcoming_result) > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while ($booking = mysqli_fetch_assoc($upcoming_result)): 
                                $images = !empty($booking['images']) ? explode(',', $booking['images']) : [];
                                $first_image = !empty($images) ? trim($images[0]) : '../assets/img/default-event.jpg';
                            ?>
                            <div class="list-group-item">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <img src="<?php echo htmlspecialchars($first_image); ?>" 
                                             alt="Event" 
                                             class="rounded" 
                                             style="width: 80px; height: 80px; object-fit: cover;"
                                             onerror="this.src='../assets/img/default-event.jpg'">
                                    </div>
                                    <div class="col">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($booking['title']); ?></h6>
                                        <small class="text-muted">
                                            <i class="bi bi-calendar3"></i> <?php echo format_date($booking['event_date']); ?> 
                                            at <?php echo format_time($booking['event_time']); ?>
                                        </small>
                                        <br>
                                        <small class="text-muted">
                                            <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($booking['venue']); ?>, 
                                            <?php echo htmlspecialchars($booking['city']); ?>
                                        </small>
                                    </div>
                                    <div class="col-auto">
                                        <span class="badge bg-success"><?php echo $booking['qty']; ?> Tickets</span>
                                        <br>
                                        <a href="../ticket/download_ticket.php?booking_id=<?php echo $booking['id']; ?>" 
                                           class="btn btn-sm btn-outline-primary mt-2">
                                            <i class="bi bi-download"></i> Ticket
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-calendar-x text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-3">No upcoming events</p>
                            <a href="../events/events.php" class="btn btn-primary">Browse Events</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions & Recommendations -->
        <div class="col-lg-4">
            <!-- Quick Actions -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="../events/events.php" class="btn btn-outline-primary">
                            <i class="bi bi-search"></i> Browse Events
                        </a>
                        <a href="wishlist.php" class="btn btn-outline-warning">
                            <i class="bi bi-heart"></i> My Wishlist
                        </a>
                        <a href="bookings.php" class="btn btn-outline-success">
                            <i class="bi bi-ticket-perforated"></i> My Bookings
                        </a>
                        <a href="profile.php" class="btn btn-outline-secondary">
                            <i class="bi bi-person"></i> Edit Profile
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- AI Recommendations -->
            <?php if (!empty($recommended_events)): ?>
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-stars text-warning"></i> Recommended</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($recommended_events as $event): 
                        $images = !empty($event['images']) ? explode(',', $event['images']) : [];
                        $first_image = !empty($images) ? trim($images[0]) : '../assets/img/default-event.jpg';
                    ?>
                    <div class="mb-3 pb-3 border-bottom">
                        <img src="<?php echo htmlspecialchars($first_image); ?>" 
                             alt="Event" 
                             class="rounded w-100 mb-2" 
                             style="height: 120px; object-fit: cover;"
                             onerror="this.src='../assets/img/default-event.jpg'">
                        <h6 class="mb-1"><?php echo htmlspecialchars($event['title']); ?></h6>
                        <small class="text-muted d-block mb-2">
                            <?php echo format_date($event['event_date']); ?>
                        </small>
                        <div class="d-flex justify-content-between align-items-center">
                            <strong class="text-primary"><?php echo format_currency($event['price']); ?></strong>
                            <a href="../events/event_detail.php?id=<?php echo $event['id']; ?>" 
                               class="btn btn-sm btn-primary">View</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

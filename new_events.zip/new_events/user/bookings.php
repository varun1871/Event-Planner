<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

$page_title = 'My Bookings';
$user_id = $_SESSION['user_id'];

// Get all bookings
$bookings_query = "SELECT b.*, e.title, e.event_date, e.event_time, e.venue, e.city, e.images, e.status as event_status
                   FROM bookings b
                   JOIN events e ON b.event_id = e.id
                   WHERE b.user_id = ?
                   ORDER BY e.event_date DESC";
$stmt = mysqli_prepare($conn, $bookings_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$bookings_result = mysqli_stmt_get_result($stmt);

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <h2 class="mb-4"><i class="bi bi-ticket-perforated"></i> My Bookings</h2>
    
    <?php if (mysqli_num_rows($bookings_result) > 0): ?>
        <div class="row g-4">
            <?php while ($booking = mysqli_fetch_assoc($bookings_result)): 
                $images = !empty($booking['images']) ? explode(',', $booking['images']) : [];
                $first_image = !empty($images) ? trim($images[0]) : '../assets/img/default-event.jpg';
                $is_past = strtotime($booking['event_date']) < time();
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm">
                    <img src="<?php echo htmlspecialchars($first_image); ?>" 
                         class="card-img-top" 
                         style="height: 200px; object-fit: cover;"
                         alt="Event"
                         onerror="this.src='../assets/img/default-event.jpg'">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($booking['title']); ?></h5>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="bi bi-calendar3"></i> <?php echo format_date($booking['event_date']); ?><br>
                                <i class="bi bi-clock"></i> <?php echo format_time($booking['event_time']); ?><br>
                                <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($booking['venue']); ?>, <?php echo htmlspecialchars($booking['city']); ?>
                            </small>
                        </p>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span><strong>Booking Code:</strong></span>
                            <code><?php echo $booking['booking_code']; ?></code>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span><strong>Tickets:</strong></span>
                            <span><?php echo $booking['qty']; ?></span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span><strong>Total:</strong></span>
                            <strong class="text-primary"><?php echo format_currency($booking['total_price']); ?></strong>
                        </div>
                        <div class="d-grid gap-2">
                            <a href="../ticket/download_ticket.php?booking_id=<?php echo $booking['id']; ?>" 
                               class="btn btn-primary btn-sm">
                                <i class="bi bi-download"></i> Download Ticket
                            </a>
                            <?php if ($is_past): ?>
                                <a href="../events/event_detail.php?id=<?php echo $booking['event_id']; ?>" 
                                   class="btn btn-outline-secondary btn-sm">
                                    <i class="bi bi-star"></i> Write Review
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">
                            Booked on <?php echo date('M d, Y', strtotime($booking['created_at'])); ?>
                        </small>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-ticket-perforated text-muted" style="font-size: 5rem;"></i>
            <h3 class="mt-3">No Bookings Yet</h3>
            <p class="text-muted">Start exploring and book your first event!</p>
            <a href="../events/events.php" class="btn btn-primary">
                <i class="bi bi-search"></i> Browse Events
            </a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

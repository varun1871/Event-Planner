<?php
require_once 'config/db.php';
require_once 'includes/ai_engine.php';

$page_title = 'Home';

// Get featured events (upcoming, published, with seats)
$featured_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                   (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                   (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count
                   FROM events e
                   JOIN categories c ON e.category_id = c.id
                   JOIN organizers o ON e.organizer_id = o.id
                   JOIN users u ON o.user_id = u.id
                   WHERE e.status = 'published' 
                   AND e.event_date >= CURDATE()
                   AND e.available_seats > 0
                   ORDER BY e.created_at DESC
                   LIMIT 6";
$featured_result = mysqli_query($conn, $featured_query);

// Get trending events (most viewed/booked)
$trending_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                   (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                   (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count,
                   (SELECT COUNT(*) FROM bookings WHERE event_id = e.id) as booking_count
                   FROM events e
                   JOIN categories c ON e.category_id = c.id
                   JOIN organizers o ON e.organizer_id = o.id
                   JOIN users u ON o.user_id = u.id
                   WHERE e.status = 'published' 
                   AND e.event_date >= CURDATE()
                   AND e.available_seats > 0
                   ORDER BY e.views DESC, booking_count DESC
                   LIMIT 6";
$trending_result = mysqli_query($conn, $trending_query);

// Get AI recommendations if user is logged in
$recommended_events = [];
if (is_logged_in()) {
    $recommended_events = get_ai_recommendations($_SESSION['user_id'], 6);
}

// Get categories
$categories_query = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = mysqli_query($conn, $categories_query);

include 'includes/header.php';
include 'includes/navbar_user.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center min-vh-75">
            <div class="col-lg-7">
                <div class="hero-content">
                    <h1 class="display-3 fw-bold mb-4 animate-fade-in">Discover Amazing Events Near You</h1>
                    <p class="lead mb-4">Find and book tickets for concerts, sports, conferences, and more. Your next unforgettable experience is just a click away.</p>
                    
                    <div class="d-flex flex-wrap gap-3 mb-5">
                        <a href="events/events.php" class="btn btn-outline-primary btn-lg px-4 py-3">
                            <i class="bi bi-search me-2"></i> Browse Events
                        </a>
                        <?php if (!is_logged_in()): ?>
                        <a href="auth/register.php" class="btn btn-outline-primary btn-lg px-4 py-3">
                            <i class="bi bi-person-plus me-2"></i> Sign Up Free
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 d-none d-lg-block">
                <div class="hero-image text-center">
                    <img src="https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?w=600&h=600&fit=crop" 
                         alt="Events" 
                         class="img-fluid rounded-4 shadow-lg" 
                         style="max-height: 500px; object-fit: cover;"
                         onerror="this.src='https://via.placeholder.com/600x600/667eea/ffffff?text=EventPlanner+Pro'">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Search Bar -->
<section class="search-section py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-11">
                <div class="card shadow-lg border-0 search-card">
                    <div class="card-body p-4">
                        <form action="events/events.php" method="GET">
                            <div class="row g-3 align-items-center">
                                <div class="col-lg-4 col-md-12">
                                    <div class="input-group input-group-lg">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class="bi bi-search text-primary"></i>
                                        </span>
                                        <input type="text" 
                                               class="form-control border-start-0 ps-0" 
                                               name="search" 
                                               placeholder="Search events, artists, venues...">
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4">
                                    <select class="form-select form-select-lg" name="category">
                                        <option value="">All Categories</option>
                                        <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                                            <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-lg-3 col-md-4">
                                    <input type="date" 
                                           class="form-control form-control-lg" 
                                           name="date" 
                                           min="<?php echo date('Y-m-d'); ?>"
                                           placeholder="Select date">
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <button type="submit" class="btn btn-primary btn-lg w-100 fw-semibold">
                                        <i class="bi bi-search me-2"></i>Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Categories -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold mb-2">Browse by Category</h2>
            <p class="text-muted">Discover events that match your interests</p>
        </div>
        <div class="row g-4">
            <?php
            mysqli_data_seek($categories_result, 0);
            $category_icons = [
                'music' => 'bi-music-note-beamed',
                'sports' => 'bi-trophy',
                'business' => 'bi-briefcase',
                'food' => 'bi-cup-straw',
                'arts' => 'bi-palette',
                'tech' => 'bi-cpu',
                'education' => 'bi-book',
                'travel' => 'bi-airplane',
                'entertainment' => 'bi-emoji-smile'
            ];
            while ($cat = mysqli_fetch_assoc($categories_result)):
                $icon = $category_icons[$cat['icon']] ?? 'bi-calendar-event';
            ?>
            <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                <a href="events/events.php?category=<?php echo $cat['id']; ?>" class="text-decoration-none">
                    <div class="card category-card text-center h-100 border-0 shadow-sm">
                        <div class="card-body p-4">
                            <div class="category-icon-wrapper mb-3">
                                <i class="bi <?php echo $icon; ?> text-primary" style="font-size: 2.5rem;"></i>
                            </div>
                            <h6 class="mb-0 fw-semibold text-dark"><?php echo htmlspecialchars($cat['name']); ?></h6>
                        </div>
                    </div>
                </a>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- AI Recommendations (for logged-in users) -->
<?php if (is_logged_in() && !empty($recommended_events)): ?>
<section class="py-5 bg-light">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1"><i class="bi bi-stars text-warning"></i> Recommended For You</h2>
                <p class="text-muted">Based on your activity and preferences</p>
            </div>
        </div>
        <div class="row g-4">
            <?php foreach ($recommended_events as $event): ?>
            <div class="col-md-6 col-lg-4">
                <?php include 'includes/event_card.php'; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Featured Events -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h2 class="fw-bold mb-2">✨ Featured Events</h2>
                <p class="text-muted mb-0">Hand-picked events you don't want to miss</p>
            </div>
            <a href="events/events.php" class="btn btn-outline-primary btn-lg px-4">
                View All <i class="bi bi-arrow-right ms-2"></i>
            </a>
        </div>
        <div class="row g-4">
            <?php while ($event = mysqli_fetch_assoc($featured_result)): ?>
            <div class="col-md-6 col-lg-4">
                <?php include 'includes/event_card.php'; ?>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- Trending Events -->
<section class="py-5 bg-white">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h2 class="fw-bold mb-2">
                    <i class="bi bi-fire text-danger"></i> Trending Now
                </h2>
                <p class="text-muted mb-0">Most popular events this week</p>
            </div>
            <a href="events/events.php?sort=trending" class="btn btn-outline-primary btn-lg px-4">
                View All <i class="bi bi-arrow-right ms-2"></i>
            </a>
        </div>
        <div class="row g-4">
            <?php while ($event = mysqli_fetch_assoc($trending_result)): ?>
            <div class="col-md-6 col-lg-4">
                <?php include 'includes/event_card.php'; ?>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <div class="cta-content">
                    <h2 class="display-5 fw-bold mb-3 text-white">Ready to Create Your Own Events?</h2>
                    <p class="lead mb-4 text-white opacity-90">Join thousands of organizers who trust EventPlanner Pro to manage their events</p>
                    <a href="auth/register.php" class="btn btn-light btn-lg px-5 py-3 fw-semibold">
                        <i class="bi bi-briefcase me-2"></i> Become an Organizer
                    </a>
                    <div class="mt-4">
                        <div class="row g-4 justify-content-center text-white">
                            <div class="col-auto">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-check-circle-fill fs-4 me-2"></i>
                                    <span>Easy Setup</span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-check-circle-fill fs-4 me-2"></i>
                                    <span>Free to Start</span>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-check-circle-fill fs-4 me-2"></i>
                                    <span>24/7 Support</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

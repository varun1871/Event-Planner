<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('admin')) {
    redirect('../auth/login.php');
}

$page_title = 'Manage Events';

// Handle event status update
if (isset($_POST['update_status'])) {
    $event_id = (int)$_POST['event_id'];
    $status = clean_input($_POST['status']);
    
    $stmt = mysqli_prepare($conn, "UPDATE events SET status = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "si", $status, $event_id);
    mysqli_stmt_execute($stmt);
    
    log_activity($_SESSION['user_id'], 'Event Status Updated', "Updated event ID: $event_id to $status");
    $_SESSION['success_message'] = 'Event status updated successfully!';
}

// Handle event deletion
if (isset($_POST['delete_event'])) {
    $event_id = (int)$_POST['event_id'];
    
    $stmt = mysqli_prepare($conn, "DELETE FROM events WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $event_id);
    mysqli_stmt_execute($stmt);
    
    log_activity($_SESSION['user_id'], 'Event Deleted', "Deleted event ID: $event_id");
    $_SESSION['success_message'] = 'Event deleted successfully!';
}

// Get all events
$events_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                 (SELECT COUNT(*) FROM bookings WHERE event_id = e.id) as booking_count
                 FROM events e
                 JOIN categories c ON e.category_id = c.id
                 JOIN organizers o ON e.organizer_id = o.id
                 JOIN users u ON o.user_id = u.id
                 ORDER BY e.created_at DESC";
$events_result = mysqli_query($conn, $events_query);

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-calendar-event"></i> Manage Events</h2>
        </div>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Organizer</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Price</th>
                            <th>Seats</th>
                            <th>Bookings</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($event = mysqli_fetch_assoc($events_result)): ?>
                        <tr>
                            <td><?php echo $event['id']; ?></td>
                            <td>
                                <a href="../events/event_detail.php?id=<?php echo $event['id']; ?>" target="_blank">
                                    <?php echo htmlspecialchars($event['title']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($event['organizer_name']); ?></td>
                            <td><?php echo htmlspecialchars($event['category_name']); ?></td>
                            <td><?php echo format_date($event['event_date']); ?></td>
                            <td><?php echo format_currency($event['price']); ?></td>
                            <td><?php echo $event['available_seats']; ?> / <?php echo $event['seats']; ?></td>
                            <td><?php echo $event['booking_count']; ?></td>
                            <td>
                                <?php
                                $badge_class = match($event['status']) {
                                    'published' => 'success',
                                    'draft' => 'warning',
                                    'cancelled' => 'danger',
                                    'completed' => 'info',
                                    default => 'secondary'
                                };
                                ?>
                                <span class="badge bg-<?php echo $badge_class; ?>">
                                    <?php echo ucfirst($event['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <?php if ($event['status'] === 'draft'): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                        <input type="hidden" name="status" value="published">
                                        <button type="submit" name="update_status" class="btn btn-success" title="Publish">
                                            <i class="bi bi-check"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <?php if ($event['status'] === 'published'): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                        <input type="hidden" name="status" value="cancelled">
                                        <button type="submit" name="update_status" class="btn btn-warning" title="Cancel">
                                            <i class="bi bi-x"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this event?');">
                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                        <button type="submit" name="delete_event" class="btn btn-danger" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

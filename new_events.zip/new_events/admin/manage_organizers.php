<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('admin')) {
    redirect('../auth/login.php');
}

$page_title = 'Manage Organizers';

// Handle approval/rejection
if (isset($_POST['update_approval'])) {
    $organizer_id = (int)$_POST['organizer_id'];
    $approved = clean_input($_POST['approved']);
    
    $stmt = mysqli_prepare($conn, "UPDATE organizers SET approved = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "si", $approved, $organizer_id);
    mysqli_stmt_execute($stmt);
    
    log_activity($_SESSION['user_id'], 'Organizer Status Updated', "Updated organizer ID: $organizer_id to $approved");
    $_SESSION['success_message'] = 'Organizer status updated successfully!';
}

// Get all organizers
$organizers_query = "SELECT o.*, u.name, u.email, u.created_at,
                     (SELECT COUNT(*) FROM events WHERE organizer_id = o.id) as event_count
                     FROM organizers o
                     JOIN users u ON o.user_id = u.id
                     ORDER BY o.created_at DESC";
$organizers_result = mysqli_query($conn, $organizers_query);

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-briefcase"></i> Manage Organizers</h2>
        </div>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Company</th>
                            <th>Phone</th>
                            <th>Events</th>
                            <th>Status</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($org = mysqli_fetch_assoc($organizers_result)): ?>
                        <tr>
                            <td><?php echo $org['id']; ?></td>
                            <td><?php echo htmlspecialchars($org['name']); ?></td>
                            <td><?php echo htmlspecialchars($org['email']); ?></td>
                            <td><?php echo htmlspecialchars($org['company_name'] ?: 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($org['phone'] ?: 'N/A'); ?></td>
                            <td><?php echo $org['event_count']; ?></td>
                            <td>
                                <?php
                                $badge_class = match($org['approved']) {
                                    'approved' => 'success',
                                    'rejected' => 'danger',
                                    default => 'warning'
                                };
                                ?>
                                <span class="badge bg-<?php echo $badge_class; ?>">
                                    <?php echo ucfirst($org['approved']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($org['created_at'])); ?></td>
                            <td>
                                <?php if ($org['approved'] === 'pending'): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="organizer_id" value="<?php echo $org['id']; ?>">
                                    <input type="hidden" name="approved" value="approved">
                                    <button type="submit" name="update_approval" class="btn btn-sm btn-success">
                                        <i class="bi bi-check"></i> Approve
                                    </button>
                                </form>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="organizer_id" value="<?php echo $org['id']; ?>">
                                    <input type="hidden" name="approved" value="rejected">
                                    <button type="submit" name="update_approval" class="btn btn-sm btn-danger">
                                        <i class="bi bi-x"></i> Reject
                                    </button>
                                </form>
                                <?php else: ?>
                                <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

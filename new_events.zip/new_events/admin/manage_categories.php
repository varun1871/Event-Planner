<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('admin')) {
    redirect('../auth/login.php');
}

$page_title = 'Manage Categories';
$error = '';
$success = '';

// Handle add category
if (isset($_POST['add_category'])) {
    $name = clean_input($_POST['name']);
    $icon = clean_input($_POST['icon']);
    
    if (empty($name)) {
        $error = 'Category name is required.';
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO categories (name, icon) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "ss", $name, $icon);
        if (mysqli_stmt_execute($stmt)) {
            $success = 'Category added successfully!';
            log_activity($_SESSION['user_id'], 'Category Added', "Added category: $name");
        } else {
            $error = 'Failed to add category.';
        }
    }
}

// Handle delete category
if (isset($_POST['delete_category'])) {
    $category_id = (int)$_POST['category_id'];
    
    $stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $category_id);
    if (mysqli_stmt_execute($stmt)) {
        $success = 'Category deleted successfully!';
        log_activity($_SESSION['user_id'], 'Category Deleted', "Deleted category ID: $category_id");
    } else {
        $error = 'Cannot delete category with existing events.';
    }
}

// Get all categories
$categories_query = "SELECT c.*, 
                     (SELECT COUNT(*) FROM events WHERE category_id = c.id) as event_count
                     FROM categories c
                     ORDER BY c.name ASC";
$categories_result = mysqli_query($conn, $categories_query);

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-tags"></i> Manage Categories</h2>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                <i class="bi bi-plus-circle"></i> Add Category
            </button>
        </div>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Icon</th>
                            <th>Events</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                        <tr>
                            <td><?php echo $cat['id']; ?></td>
                            <td><?php echo htmlspecialchars($cat['name']); ?></td>
                            <td><i class="bi bi-<?php echo htmlspecialchars($cat['icon']); ?>"></i></td>
                            <td><?php echo $cat['event_count']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($cat['created_at'])); ?></td>
                            <td>
                                <?php if ($cat['event_count'] == 0): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                                    <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                    <button type="submit" name="delete_category" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </form>
                                <?php else: ?>
                                <span class="text-muted">Cannot delete</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Category Modal -->
<div class="modal fade" id="addCategoryModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Category Name *</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Icon (Bootstrap Icon name)</label>
                        <input type="text" class="form-control" name="icon" placeholder="e.g., music-note">
                        <small class="text-muted">Visit <a href="https://icons.getbootstrap.com/" target="_blank">Bootstrap Icons</a></small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('admin')) {
    redirect('../auth/login.php');
}

$page_title = 'System Logs';

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 50;
$offset = ($page - 1) * $per_page;

// Get total count
$count_query = "SELECT COUNT(*) as total FROM logs";
$count_result = mysqli_query($conn, $count_query);
$total_logs = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_logs / $per_page);

// Get logs
$logs_query = "SELECT l.*, u.name as user_name, u.email
               FROM logs l
               LEFT JOIN users u ON l.user_id = u.id
               ORDER BY l.created_at DESC
               LIMIT $per_page OFFSET $offset";
$logs_result = mysqli_query($conn, $logs_query);

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-journal-text"></i> System Logs</h2>
            <p class="text-muted">Track all system activities and user actions</p>
        </div>
    </div>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>IP Address</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($log = mysqli_fetch_assoc($logs_result)): ?>
                        <tr>
                            <td><?php echo $log['id']; ?></td>
                            <td>
                                <?php if ($log['user_name']): ?>
                                    <?php echo htmlspecialchars($log['user_name']); ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($log['email']); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">System</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($log['action']); ?></strong></td>
                            <td><?php echo htmlspecialchars($log['description'] ?: '-'); ?></td>
                            <td><code><?php echo htmlspecialchars($log['ip_address']); ?></code></td>
                            <td><?php echo date('M d, Y h:i A', strtotime($log['created_at'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <nav class="mt-3">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('admin')) {
    redirect('../auth/login.php');
}

$page_title = 'System Settings';
$success = '';
$error = '';

// Get current settings
$settings_query = "SELECT * FROM settings WHERE id = 1";
$settings_result = mysqli_query($conn, $settings_query);
$settings = mysqli_fetch_assoc($settings_result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_title = clean_input($_POST['site_title']);
    $contact_email = clean_input($_POST['contact_email']);
    $contact_phone = clean_input($_POST['contact_phone']);
    $contact_address = clean_input($_POST['contact_address']);
    
    if (empty($site_title) || empty($contact_email)) {
        $error = 'Site title and contact email are required.';
    } elseif (!filter_var($contact_email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE settings SET site_title = ?, contact_email = ?, contact_phone = ?, contact_address = ? WHERE id = 1");
        mysqli_stmt_bind_param($stmt, "ssss", $site_title, $contact_email, $contact_phone, $contact_address);
        
        if (mysqli_stmt_execute($stmt)) {
            $success = 'Settings updated successfully!';
            log_activity($_SESSION['user_id'], 'Settings Updated', 'System settings were updated');
            
            // Refresh settings
            $settings_result = mysqli_query($conn, $settings_query);
            $settings = mysqli_fetch_assoc($settings_result);
        } else {
            $error = 'Failed to update settings.';
        }
    }
}

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-gear"></i> System Settings</h2>
        </div>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">General Settings</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Site Title *</label>
                            <input type="text" class="form-control" name="site_title" 
                                   value="<?php echo htmlspecialchars($settings['site_title']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Contact Email *</label>
                            <input type="email" class="form-control" name="contact_email" 
                                   value="<?php echo htmlspecialchars($settings['contact_email']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Contact Phone</label>
                            <input type="text" class="form-control" name="contact_phone" 
                                   value="<?php echo htmlspecialchars($settings['contact_phone']); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Contact Address</label>
                            <textarea class="form-control" name="contact_address" rows="3"><?php echo htmlspecialchars($settings['contact_address']); ?></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle"></i> Save Settings
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">System Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
                    <p><strong>MySQL Version:</strong> <?php echo mysqli_get_server_info($conn); ?></p>
                    <p><strong>Server:</strong> <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
                    <p><strong>Last Updated:</strong> <?php echo date('M d, Y h:i A', strtotime($settings['updated_at'])); ?></p>
                </div>
            </div>
            
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="admin_dashboard.php" class="btn btn-outline-primary">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a href="manage_users.php" class="btn btn-outline-primary">
                            <i class="bi bi-people"></i> Manage Users
                        </a>
                        <a href="manage_events.php" class="btn btn-outline-primary">
                            <i class="bi bi-calendar-event"></i> Manage Events
                        </a>
                        <a href="logs.php" class="btn btn-outline-primary">
                            <i class="bi bi-journal-text"></i> View Logs
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

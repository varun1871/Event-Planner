<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('admin')) {
    redirect('../auth/login.php');
}

$page_title = 'Admin Dashboard';

// Get statistics
$stats = [];

// Total users
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role = 'user'");
$stats['users'] = mysqli_fetch_assoc($result)['total'];

// Total organizers
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM organizers WHERE approved = 'approved'");
$stats['organizers'] = mysqli_fetch_assoc($result)['total'];

// Pending organizers
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM organizers WHERE approved = 'pending'");
$stats['pending_organizers'] = mysqli_fetch_assoc($result)['total'];

// Total events
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM events WHERE status = 'published'");
$stats['events'] = mysqli_fetch_assoc($result)['total'];

// Total bookings
$result = mysqli_query($conn, "SELECT COUNT(*) as total, SUM(total_price) as revenue FROM bookings");
$booking_stats = mysqli_fetch_assoc($result);
$stats['bookings'] = $booking_stats['total'];
$stats['revenue'] = $booking_stats['revenue'] ?? 0;

// Recent bookings
$recent_bookings_query = "SELECT b.*, e.title, u.name as user_name
                          FROM bookings b
                          JOIN events e ON b.event_id = e.id
                          JOIN users u ON b.user_id = u.id
                          ORDER BY b.created_at DESC
                          LIMIT 10";
$recent_bookings = mysqli_query($conn, $recent_bookings_query);

// Monthly revenue data for chart
$monthly_revenue_query = "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, 
                          SUM(total_price) as revenue,
                          COUNT(*) as bookings
                          FROM bookings
                          WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                          GROUP BY month
                          ORDER BY month ASC";
$monthly_revenue = mysqli_query($conn, $monthly_revenue_query);

$months = [];
$revenues = [];
while ($row = mysqli_fetch_assoc($monthly_revenue)) {
    $months[] = date('M Y', strtotime($row['month'] . '-01'));
    $revenues[] = $row['revenue'];
}

// Category distribution
$category_query = "SELECT c.name, COUNT(e.id) as count
                   FROM categories c
                   LEFT JOIN events e ON c.id = e.category_id AND e.status = 'published'
                   GROUP BY c.id
                   ORDER BY count DESC
                   LIMIT 5";
$category_result = mysqli_query($conn, $category_query);

$categories = [];
$category_counts = [];
while ($row = mysqli_fetch_assoc($category_result)) {
    $categories[] = $row['name'];
    $category_counts[] = $row['count'];
}

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid my-4">
    <div class="row mb-4">
        <div class="col">
            <h2>Admin Dashboard</h2>
            <p class="text-muted">Overview of your event platform</p>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4 col-lg-2">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-people text-primary fs-1"></i>
                    <h3 class="mt-2"><?php echo $stats['users']; ?></h3>
                    <p class="text-muted mb-0">Users</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 col-lg-2">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-briefcase text-info fs-1"></i>
                    <h3 class="mt-2"><?php echo $stats['organizers']; ?></h3>
                    <p class="text-muted mb-0">Organizers</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 col-lg-2">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-clock-history text-warning fs-1"></i>
                    <h3 class="mt-2"><?php echo $stats['pending_organizers']; ?></h3>
                    <p class="text-muted mb-0">Pending</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 col-lg-2">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-calendar-event text-success fs-1"></i>
                    <h3 class="mt-2"><?php echo $stats['events']; ?></h3>
                    <p class="text-muted mb-0">Events</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 col-lg-2">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <i class="bi bi-ticket-perforated text-danger fs-1"></i>
                    <h3 class="mt-2"><?php echo $stats['bookings']; ?></h3>
                    <p class="text-muted mb-0">Bookings</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 col-lg-2">
            <div class="card shadow-sm bg-primary text-white">
                <div class="card-body text-center">
                    <i class="bi bi-currency-dollar fs-1"></i>
                    <h3 class="mt-2"><?php echo format_currency($stats['revenue']); ?></h3>
                    <p class="mb-0">Revenue</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Revenue Chart -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-graph-up"></i> Revenue Trend (Last 6 Months)</h5>
                </div>
                <div class="card-body">
                    <canvas id="revenueChart" height="80"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Category Distribution -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-pie-chart"></i> Top Categories</h5>
                </div>
                <div class="card-body">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Bookings -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent Bookings</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Booking Code</th>
                                    <th>User</th>
                                    <th>Event</th>
                                    <th>Quantity</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($booking = mysqli_fetch_assoc($recent_bookings)): ?>
                                <tr>
                                    <td><code><?php echo $booking['booking_code']; ?></code></td>
                                    <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['title']); ?></td>
                                    <td><?php echo $booking['qty']; ?></td>
                                    <td><?php echo format_currency($booking['total_price']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($booking['created_at'])); ?></td>
                                    <td><span class="badge bg-success"><?php echo ucfirst($booking['status']); ?></span></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Revenue Chart
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($months); ?>,
        datasets: [{
            label: 'Revenue',
            data: <?php echo json_encode($revenues); ?>,
            borderColor: '#667eea',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '$' + value.toLocaleString();
                    }
                }
            }
        }
    }
});

// Category Chart
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode($categories); ?>,
        datasets: [{
            data: <?php echo json_encode($category_counts); ?>,
            backgroundColor: [
                '#667eea',
                '#764ba2',
                '#f093fb',
                '#4facfe',
                '#43e97b'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>

<?php include '../includes/footer.php'; ?>

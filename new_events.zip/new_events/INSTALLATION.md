# 📦 EventPlanner Pro - Installation Guide

Complete step-by-step installation instructions for XAMPP.

---

## 🎯 Quick Start (5 Minutes)

### Step 1: Install XAMPP
1. Download XAMPP from: https://www.apachefriends.org/
2. Install XAMPP to `C:\xampp\`
3. Run XAMPP Control Panel as Administrator

### Step 2: Start Services
1. Click **Start** next to Apache
2. Click **Start** next to MySQL
3. Wait for both to show green "Running" status

### Step 3: Import Database
1. Open browser and go to: http://localhost/phpmyadmin
2. Click **"New"** in left sidebar
3. Create database named: `eventplanner`
4. Click on `eventplanner` database
5. Click **"Import"** tab at top
6. Click **"Choose File"** button
7. Select: `C:\xampp\htdocs\new_events\eventplanner.sql`
8. Click **"Go"** button at bottom
9. Wait for success message

### Step 4: Access Application
1. Open browser
2. Go to: http://localhost/new_events/
3. You should see the homepage!

---

## 🔐 Login Credentials

### Admin Access
```
URL: http://localhost/new_events/auth/login.php
Email: admin@eventplanner.com
Password: admin123
```

### Create New User
```
URL: http://localhost/new_events/auth/register.php
Fill in the registration form
```

---

## ✅ Verification Checklist

After installation, verify these work:

- [ ] Homepage loads at http://localhost/new_events/
- [ ] Can login as admin
- [ ] Admin dashboard shows statistics
- [ ] Can register new user account
- [ ] Can browse events page
- [ ] No PHP errors displayed

---

## 🐛 Common Issues & Solutions

### Issue 1: "Connection failed" Error
**Problem:** Cannot connect to database

**Solution:**
1. Check MySQL is running in XAMPP
2. Open `config/db.php`
3. Verify these settings:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'eventplanner');
   ```
4. Make sure database `eventplanner` exists in phpMyAdmin

### Issue 2: Apache Won't Start
**Problem:** Port 80 already in use

**Solution:**
1. Close Skype or other programs using port 80
2. OR change Apache port:
   - Click "Config" → "httpd.conf"
   - Find: `Listen 80`
   - Change to: `Listen 8080`
   - Save and restart Apache
   - Access via: http://localhost:8080/new_events/

### Issue 3: MySQL Won't Start
**Problem:** Port 3306 already in use

**Solution:**
1. Stop other MySQL services
2. OR change MySQL port in XAMPP config
3. Update port in `config/db.php`

### Issue 4: Blank Page
**Problem:** White screen, no errors

**Solution:**
1. Enable error display:
   - Open `C:\xampp\php\php.ini`
   - Find: `display_errors = Off`
   - Change to: `display_errors = On`
   - Restart Apache
2. Check PHP error log: `C:\xampp\php\logs\php_error_log`

### Issue 5: Permission Denied
**Problem:** Cannot write files

**Solution:**
1. Run XAMPP Control Panel as Administrator
2. Right-click `C:\xampp\htdocs\new_events\`
3. Properties → Security → Edit
4. Give "Users" full control

---

## 🔧 Configuration Options

### Change Database Credentials
Edit `config/db.php`:
```php
define('DB_HOST', 'localhost');    // Database host
define('DB_USER', 'root');         // Database username
define('DB_PASS', '');             // Database password
define('DB_NAME', 'eventplanner'); // Database name
```

### Change Base URL
If not using default location, update paths in:
- `includes/header.php` - getBaseUrl() function
- All navigation files

---

## 📊 Database Setup Details

### Tables Created:
- `users` - User accounts
- `organizers` - Organizer profiles
- `categories` - Event categories (10 default)
- `events` - Event listings
- `bookings` - Ticket bookings
- `wishlist` - User wishlists
- `reviews` - Event reviews
- `logs` - Activity logs
- `ai_user_activity` - AI tracking
- `ai_event_scores` - AI scores
- `settings` - System settings

### Default Data:
- 1 Admin user
- 10 Event categories
- System settings

---

## 🚀 Post-Installation Steps

### 1. Create Sample Events
1. Register as organizer
2. Wait for admin approval (or approve yourself via admin panel)
3. Create sample events with:
   - Event details
   - Images (use URLs from Unsplash)
   - Pricing and seats

### 2. Test User Flow
1. Register as regular user
2. Browse events
3. Add to cart
4. Complete checkout
5. Download ticket

### 3. Test AI Recommendations
1. Create multiple user accounts
2. Browse different categories
3. Add to wishlist
4. Book events
5. Check recommendations on dashboard

### 4. Customize Settings
1. Login as admin
2. Go to Settings page
3. Update:
   - Site title
   - Contact information
   - Logo (if needed)

---

## 📁 File Permissions

Ensure these folders are writable:
```
new_events/
├── assets/img/        (for uploads, if implemented)
└── logs/              (for error logs, if implemented)
```

---

## 🔒 Security Recommendations

### For Production Use:
1. **Change admin password** immediately
2. **Update database credentials** to strong password
3. **Enable HTTPS** with SSL certificate
4. **Disable error display** in production
5. **Set up regular backups** of database
6. **Update PHP** to latest version
7. **Review file permissions** carefully

### Recommended php.ini Settings:
```ini
display_errors = Off
log_errors = On
error_log = C:\xampp\php\logs\php_error_log
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 30
```

---

## 🧪 Testing the Installation

### Test Checklist:
```
✓ Homepage loads
✓ User registration works
✓ User login works
✓ Admin login works
✓ Event browsing works
✓ Search and filters work
✓ Add to cart works
✓ Checkout process works
✓ Ticket download works
✓ Wishlist toggle works
✓ Review submission works
✓ Organizer dashboard works
✓ Admin dashboard works
✓ AI recommendations appear
```

---

## 📞 Support

### If You Need Help:
1. Check error logs: `C:\xampp\php\logs\`
2. Review Apache logs: `C:\xampp\apache\logs\`
3. Check MySQL logs: `C:\xampp\mysql\data\`
4. Verify all files are in correct location
5. Ensure XAMPP services are running

### Useful Commands:
```bash
# Check PHP version
php -v

# Check MySQL connection
mysql -u root -p

# Restart Apache (via XAMPP Control Panel)
# Stop → Start
```

---

## 🎉 Success!

If everything works:
- ✅ You can access the homepage
- ✅ You can login as admin
- ✅ You can create events
- ✅ You can book tickets
- ✅ AI recommendations work

**Congratulations! Your EventPlanner Pro is ready to use!**

---

## 📚 Next Steps

1. Read the main README.md for features
2. Explore the admin panel
3. Create sample events
4. Test all features
5. Customize as needed

---

**Need more help? Check the README.md file for detailed documentation!**

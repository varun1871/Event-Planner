<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

$page_title = 'Shopping Cart';

// Handle cart updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $event_id = (int)$_POST['event_id'];
        
        if ($_POST['action'] === 'remove') {
            unset($_SESSION['cart'][$event_id]);
        } elseif ($_POST['action'] === 'update') {
            $quantity = (int)$_POST['quantity'];
            if ($quantity > 0) {
                $_SESSION['cart'][$event_id]['quantity'] = $quantity;
            } else {
                unset($_SESSION['cart'][$event_id]);
            }
        }
    }
}

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <h2 class="mb-4"><i class="bi bi-cart3"></i> Shopping Cart</h2>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($cart_items)): ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Event</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Subtotal</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $item): 
                                    $subtotal = $item['price'] * $item['quantity'];
                                    $total += $subtotal;
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($item['title']); ?></strong>
                                    </td>
                                    <td><?php echo format_currency($item['price']); ?></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="event_id" value="<?php echo $item['event_id']; ?>">
                                            <input type="hidden" name="action" value="update">
                                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                                   min="1" max="10" class="form-control form-control-sm" style="width: 80px;"
                                                   onchange="this.form.submit()">
                                        </form>
                                    </td>
                                    <td><strong><?php echo format_currency($subtotal); ?></strong></td>
                                    <td>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="event_id" value="<?php echo $item['event_id']; ?>">
                                            <input type="hidden" name="action" value="remove">
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal:</span>
                            <strong><?php echo format_currency($total); ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Service Fee:</span>
                            <strong>$0.00</strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <h5>Total:</h5>
                            <h5 class="text-primary"><?php echo format_currency($total); ?></h5>
                        </div>
                        <a href="checkout.php" class="btn btn-primary w-100 mb-2">
                            <i class="bi bi-credit-card"></i> Proceed to Checkout
                        </a>
                        <a href="../events/events.php" class="btn btn-outline-secondary w-100">
                            <i class="bi bi-arrow-left"></i> Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-cart-x text-muted" style="font-size: 5rem;"></i>
            <h3 class="mt-3">Your cart is empty</h3>
            <p class="text-muted">Start adding events to your cart!</p>
            <a href="../events/events.php" class="btn btn-primary">
                <i class="bi bi-search"></i> Browse Events
            </a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

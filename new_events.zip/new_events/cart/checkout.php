<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

$page_title = 'Checkout';
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

if (empty($cart_items)) {
    redirect('cart.php');
}

$total = 0;
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    mysqli_begin_transaction($conn);
    
    try {
        $all_bookings = [];
        
        foreach ($cart_items as $item) {
            // Check seat availability
            $stmt = mysqli_prepare($conn, "SELECT available_seats FROM events WHERE id = ? FOR UPDATE");
            mysqli_stmt_bind_param($stmt, "i", $item['event_id']);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $event = mysqli_fetch_assoc($result);
            
            if ($event['available_seats'] < $item['quantity']) {
                throw new Exception("Not enough seats available for " . $item['title']);
            }
            
            // Create booking
            $booking_code = generate_booking_code();
            $total_price = $item['price'] * $item['quantity'];
            
            $stmt = mysqli_prepare($conn, "INSERT INTO bookings (user_id, event_id, qty, total_price, booking_code, status) VALUES (?, ?, ?, ?, ?, 'confirmed')");
            mysqli_stmt_bind_param($stmt, "iiids", $_SESSION['user_id'], $item['event_id'], $item['quantity'], $total_price, $booking_code);
            mysqli_stmt_execute($stmt);
            
            $booking_id = mysqli_insert_id($conn);
            $all_bookings[] = [
                'booking_id' => $booking_id,
                'booking_code' => $booking_code,
                'event_title' => $item['title']
            ];
            
            // Update available seats
            $stmt = mysqli_prepare($conn, "UPDATE events SET available_seats = available_seats - ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "ii", $item['quantity'], $item['event_id']);
            mysqli_stmt_execute($stmt);
            
            // Track booking activity
            track_user_activity($_SESSION['user_id'], 'booking', $item['event_id']);
            
            // Update event scores
            update_event_scores($item['event_id']);
        }
        
        mysqli_commit($conn);
        
        // Log activity
        log_activity($_SESSION['user_id'], 'Booking Created', 'User booked ' . count($cart_items) . ' events');
        
        // Clear cart
        unset($_SESSION['cart']);
        
        // Store booking info in session for success page
        $_SESSION['completed_bookings'] = $all_bookings;
        
        redirect('success.php');
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $error = $e->getMessage();
    }
}

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-8">
            <h2 class="mb-4"><i class="bi bi-credit-card"></i> Checkout</h2>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="card shadow-sm mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Order Details</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Event</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart_items as $item): 
                                $subtotal = $item['price'] * $item['quantity'];
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['title']); ?></td>
                                <td><?php echo format_currency($item['price']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo format_currency($subtotal); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0">Payment Information</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> This is a demo system. No actual payment will be processed.
                    </div>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Card Number</label>
                                <input type="text" class="form-control" placeholder="1234 5678 9012 3456" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Cardholder Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Expiry Month</label>
                                <select class="form-select" required>
                                    <option value="">MM</option>
                                    <?php for ($i = 1; $i <= 12; $i++): ?>
                                        <option value="<?php echo sprintf('%02d', $i); ?>"><?php echo sprintf('%02d', $i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Expiry Year</label>
                                <select class="form-select" required>
                                    <option value="">YYYY</option>
                                    <?php for ($i = date('Y'); $i <= date('Y') + 10; $i++): ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">CVV</label>
                                <input type="text" class="form-control" placeholder="123" maxlength="4" required>
                            </div>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" id="terms" required>
                            <label class="form-check-label" for="terms">
                                I agree to the terms and conditions
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-lg w-100">
                            <i class="bi bi-lock"></i> Complete Purchase - <?php echo format_currency($total); ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card shadow-sm sticky-top" style="top: 80px;">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Order Summary</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <strong><?php echo format_currency($total); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Service Fee:</span>
                        <strong>$0.00</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tax:</span>
                        <strong>$0.00</strong>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <h5>Total:</h5>
                        <h5 class="text-primary"><?php echo format_currency($total); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

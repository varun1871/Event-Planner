<?php
require_once '../config/db.php';

if (!is_logged_in() || !isset($_SESSION['completed_bookings'])) {
    redirect('../index.php');
}

$page_title = 'Booking Successful';
$bookings = $_SESSION['completed_bookings'];
unset($_SESSION['completed_bookings']);

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-body text-center py-5">
                    <div class="mb-4">
                        <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
                    </div>
                    <h1 class="mb-3">Booking Successful!</h1>
                    <p class="lead text-muted mb-4">
                        Your tickets have been confirmed. Check your email for booking details.
                    </p>
                    
                    <div class="alert alert-info text-start">
                        <h5><i class="bi bi-info-circle"></i> Your Bookings:</h5>
                        <ul class="mb-0">
                            <?php foreach ($bookings as $booking): ?>
                                <li>
                                    <strong><?php echo htmlspecialchars($booking['event_title']); ?></strong>
                                    <br>
                                    <small>Booking Code: <code><?php echo $booking['booking_code']; ?></code></small>
                                    <br>
                                    <a href="../ticket/download_ticket.php?booking_id=<?php echo $booking['booking_id']; ?>" 
                                       class="btn btn-sm btn-primary mt-1">
                                        <i class="bi bi-download"></i> Download Ticket
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <div class="d-flex gap-3 justify-content-center mt-4">
                        <a href="../user/bookings.php" class="btn btn-primary">
                            <i class="bi bi-ticket-perforated"></i> View My Bookings
                        </a>
                        <a href="../events/events.php" class="btn btn-outline-primary">
                            <i class="bi bi-search"></i> Browse More Events
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

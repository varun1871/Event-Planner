<?php
require_once '../config/db.php';

if (!is_logged_in()) {
    redirect('../auth/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_id = (int)$_POST['event_id'];
    $quantity = (int)$_POST['quantity'];
    
    // Validate event
    $stmt = mysqli_prepare($conn, "SELECT id, title, price, available_seats FROM events WHERE id = ? AND status = 'published'");
    mysqli_stmt_bind_param($stmt, "i", $event_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $event = mysqli_fetch_assoc($result);
    
    if ($event && $quantity > 0 && $quantity <= $event['available_seats']) {
        // Initialize cart if not exists
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Add or update cart item
        if (isset($_SESSION['cart'][$event_id])) {
            $_SESSION['cart'][$event_id]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$event_id] = [
                'event_id' => $event_id,
                'title' => $event['title'],
                'price' => $event['price'],
                'quantity' => $quantity
            ];
        }
        
        $_SESSION['success_message'] = 'Event added to cart successfully!';
        redirect('../cart/cart.php');
    } else {
        $_SESSION['error_message'] = 'Invalid event or quantity.';
        redirect('../events/event_detail.php?id=' . $event_id);
    }
} else {
    redirect('../events/events.php');
}
?>

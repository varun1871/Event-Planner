<nav class="navbar navbar-expand-lg navbar-light bg-white navbar-professional shadow-sm sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold brand-text text-dark" href="<?php echo getBaseUrl(); ?>/organizer/organizer_dashboard.php">
            <i class="bi bi-briefcase"></i> Organizer Panel
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#organizerNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="organizerNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link nav-link-professional" href="<?php echo getBaseUrl(); ?>/organizer/organizer_dashboard.php">
                        <i class="bi bi-speedometer2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-professional" href="<?php echo getBaseUrl(); ?>/organizer/my_events.php">
                        <i class="bi bi-calendar3"></i> My Events
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-professional" href="<?php echo getBaseUrl(); ?>/organizer/add_event.php">
                        <i class="bi bi-plus-circle"></i> Add Event
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-professional" href="<?php echo getBaseUrl(); ?>/organizer/bookings.php">
                        <i class="bi bi-ticket-perforated"></i> Bookings
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link nav-link-professional" href="<?php echo getBaseUrl(); ?>/index.php">
                        <i class="bi bi-house-door"></i> Home
                    </a>
                </li>
                <li class="nav-item">
                    <button class="nav-link nav-link-professional border-0 bg-transparent" id="themeToggle" title="Toggle Dark Mode">
                        <i class="bi bi-moon-stars"></i>
                    </button>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle nav-link-professional" href="#" id="organizerDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/user/profile.php">
                            <i class="bi bi-person"></i> Profile
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?php echo getBaseUrl(); ?>/auth/logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<?php
/**
 * AI Recommendation Engine
 * Pure PHP + MySQL based recommendation system
 */

/**
 * Track user activity for AI learning
 */
function track_user_activity($user_id, $activity_type, $event_id = null, $category_id = null, $search_term = null) {
    global $conn;
    
    $stmt = mysqli_prepare($conn, "INSERT INTO ai_user_activity (user_id, event_id, category_id, activity_type, search_term) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "iiiss", $user_id, $event_id, $category_id, $activity_type, $search_term);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/**
 * Update event scores for AI recommendations
 */
function update_event_scores($event_id) {
    global $conn;
    
    // Get event stats
    $stats_query = "SELECT 
                    (SELECT COUNT(*) FROM bookings WHERE event_id = ?) as booking_count,
                    (SELECT COUNT(*) FROM wishlist WHERE event_id = ?) as wishlist_count,
                    (SELECT AVG(rating) FROM reviews WHERE event_id = ?) as avg_rating,
                    (SELECT views FROM events WHERE id = ?) as views";
    
    $stmt = mysqli_prepare($conn, $stats_query);
    mysqli_stmt_bind_param($stmt, "iiii", $event_id, $event_id, $event_id, $event_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $stats = mysqli_fetch_assoc($result);
    
    // Calculate scores (normalized to 0-100)
    $booking_score = min(100, ($stats['booking_count'] ?? 0) * 5);
    $view_score = min(100, ($stats['views'] ?? 0) * 0.5);
    $rating_score = ($stats['avg_rating'] ?? 0) * 20;
    $popularity_score = ($booking_score * 0.4) + ($view_score * 0.3) + ($rating_score * 0.3);
    
    // Final score
    $final_score = $popularity_score;
    
    // Insert or update scores
    $update_query = "INSERT INTO ai_event_scores (event_id, popularity_score, rating_score, booking_score, view_score, final_score) 
                     VALUES (?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE 
                     popularity_score = VALUES(popularity_score),
                     rating_score = VALUES(rating_score),
                     booking_score = VALUES(booking_score),
                     view_score = VALUES(view_score),
                     final_score = VALUES(final_score)";
    
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "iddddd", $event_id, $popularity_score, $rating_score, $booking_score, $view_score, $final_score);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/**
 * Get AI-powered event recommendations for a user
 */
function get_ai_recommendations($user_id, $limit = 10) {
    global $conn;
    
    // Get user's activity history
    $activity_query = "SELECT DISTINCT category_id FROM ai_user_activity 
                       WHERE user_id = ? AND category_id IS NOT NULL 
                       ORDER BY created_at DESC LIMIT 5";
    $stmt = mysqli_prepare($conn, $activity_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $preferred_categories = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $preferred_categories[] = $row['category_id'];
    }
    
    // Get user's booked/wishlisted events
    $viewed_events_query = "SELECT DISTINCT event_id FROM (
                            SELECT event_id FROM bookings WHERE user_id = ?
                            UNION
                            SELECT event_id FROM wishlist WHERE user_id = ?
                            UNION
                            SELECT event_id FROM ai_user_activity WHERE user_id = ? AND activity_type = 'view'
                            ) as viewed";
    $stmt = mysqli_prepare($conn, $viewed_events_query);
    mysqli_stmt_bind_param($stmt, "iii", $user_id, $user_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $viewed_events = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $viewed_events[] = $row['event_id'];
    }
    
    // Build recommendation query
    $recommendations_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                              (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                              (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count,
                              COALESCE(s.final_score, 0) as ai_score";
    
    // Add category match score only if user has preferred categories
    if (!empty($preferred_categories)) {
        $recommendations_query .= ",
                              CASE 
                                WHEN e.category_id IN (" . implode(',', array_fill(0, count($preferred_categories), '?')) . ") THEN 50
                                ELSE 0
                              END as category_match_score";
    } else {
        $recommendations_query .= ", 0 as category_match_score";
    }
    
    $recommendations_query .= "
                              FROM events e
                              JOIN categories c ON e.category_id = c.id
                              JOIN organizers o ON e.organizer_id = o.id
                              JOIN users u ON o.user_id = u.id
                              LEFT JOIN ai_event_scores s ON e.id = s.event_id
                              WHERE e.status = 'published' 
                              AND e.event_date >= CURDATE()
                              AND e.available_seats > 0";
    
    // Exclude already viewed events
    if (!empty($viewed_events)) {
        $recommendations_query .= " AND e.id NOT IN (" . implode(',', array_fill(0, count($viewed_events), '?')) . ")";
    }
    
    $recommendations_query .= " ORDER BY (ai_score + category_match_score) DESC, e.created_at DESC LIMIT ?";
    
    // Prepare and execute
    $stmt = mysqli_prepare($conn, $recommendations_query);
    
    $params = array_merge($preferred_categories, $viewed_events, [$limit]);
    $types = str_repeat('i', count($preferred_categories) + count($viewed_events)) . 'i';
    
    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $recommendations = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $recommendations[] = $row;
    }
    
    mysqli_stmt_close($stmt);
    
    return $recommendations;
}

/**
 * Get similar events based on category and attributes
 */
function get_similar_events($event_id, $limit = 6) {
    global $conn;
    
    // Get the event details
    $event_query = "SELECT category_id, city, price FROM events WHERE id = ?";
    $stmt = mysqli_prepare($conn, $event_query);
    mysqli_stmt_bind_param($stmt, "i", $event_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $event = mysqli_fetch_assoc($result);
    
    if (!$event) {
        return [];
    }
    
    // Find similar events
    $similar_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                      (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                      (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count,
                      CASE 
                        WHEN e.category_id = ? THEN 50
                        ELSE 0
                      END +
                      CASE 
                        WHEN e.city = ? THEN 30
                        ELSE 0
                      END +
                      CASE 
                        WHEN ABS(e.price - ?) < 50 THEN 20
                        ELSE 0
                      END as similarity_score
                      FROM events e
                      JOIN categories c ON e.category_id = c.id
                      JOIN organizers o ON e.organizer_id = o.id
                      JOIN users u ON o.user_id = u.id
                      WHERE e.status = 'published' 
                      AND e.event_date >= CURDATE()
                      AND e.available_seats > 0
                      AND e.id != ?
                      ORDER BY similarity_score DESC, e.views DESC
                      LIMIT ?";
    
    $stmt = mysqli_prepare($conn, $similar_query);
    mysqli_stmt_bind_param($stmt, "isdii", $event['category_id'], $event['city'], $event['price'], $event_id, $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $similar_events = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $similar_events[] = $row;
    }
    
    mysqli_stmt_close($stmt);
    
    return $similar_events;
}

/**
 * Get trending events based on recent activity
 */
function get_trending_events($limit = 10) {
    global $conn;
    
    $query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
              (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
              (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count,
              (SELECT COUNT(*) FROM bookings WHERE event_id = e.id AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as recent_bookings,
              COALESCE(s.final_score, 0) as ai_score
              FROM events e
              JOIN categories c ON e.category_id = c.id
              JOIN organizers o ON e.organizer_id = o.id
              JOIN users u ON o.user_id = u.id
              LEFT JOIN ai_event_scores s ON e.id = s.event_id
              WHERE e.status = 'published' 
              AND e.event_date >= CURDATE()
              AND e.available_seats > 0
              ORDER BY recent_bookings DESC, e.views DESC, ai_score DESC
              LIMIT ?";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $trending = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $trending[] = $row;
    }
    
    mysqli_stmt_close($stmt);
    
    return $trending;
}

/**
 * Update all event scores (run periodically)
 */
function update_all_event_scores() {
    global $conn;
    
    $query = "SELECT id FROM events WHERE status = 'published'";
    $result = mysqli_query($conn, $query);
    
    while ($row = mysqli_fetch_assoc($result)) {
        update_event_scores($row['id']);
    }
}
?>

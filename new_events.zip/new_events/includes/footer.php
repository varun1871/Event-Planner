    <!-- Footer -->
    <footer class="footer-professional bg-dark text-white mt-5">
        <div class="container py-5">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6 mb-4">
                    <h5 class="footer-brand mb-3">
                        <i class="bi bi-calendar-event me-2"></i>EventPlanner Pro
                    </h5>
                    <p class="footer-description mb-4">Your premier destination for discovering and booking amazing events. From concerts to conferences, we've got you covered.</p>
                    <div class="social-links">
                        <a href="#" class="social-icon" aria-label="Facebook">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="social-icon" aria-label="Twitter">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="social-icon" aria-label="Instagram">
                            <i class="bi bi-instagram"></i>
                        </a>
                        <a href="#" class="social-icon" aria-label="LinkedIn">
                            <i class="bi bi-linkedin"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="footer-heading mb-3">Quick Links</h6>
                    <ul class="footer-links list-unstyled">
                        <li><a href="<?php echo getBaseUrl(); ?>/index.php"><i class="bi bi-chevron-right me-1"></i>Home</a></li>
                        <li><a href="<?php echo getBaseUrl(); ?>/events/events.php"><i class="bi bi-chevron-right me-1"></i>Events</a></li>
                        <li><a href="#"><i class="bi bi-chevron-right me-1"></i>About Us</a></li>
                        <li><a href="#"><i class="bi bi-chevron-right me-1"></i>Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="footer-heading mb-3">Categories</h6>
                    <ul class="footer-links list-unstyled">
                        <li><a href="#"><i class="bi bi-chevron-right me-1"></i>Music & Concerts</a></li>
                        <li><a href="#"><i class="bi bi-chevron-right me-1"></i>Sports & Fitness</a></li>
                        <li><a href="#"><i class="bi bi-chevron-right me-1"></i>Business</a></li>
                        <li><a href="#"><i class="bi bi-chevron-right me-1"></i>Arts & Culture</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="footer-heading mb-3">Contact Info</h6>
                    <ul class="footer-contact list-unstyled">
                        <li>
                            <i class="bi bi-envelope-fill me-2"></i>
                            <a href="mailto:contact@eventplanner.com">contact@eventplanner.com</a>
                        </li>
                        <li>
                            <i class="bi bi-telephone-fill me-2"></i>
                            <a href="tel:+12345678900">+1-234-567-8900</a>
                        </li>
                        <li>
                            <i class="bi bi-geo-alt-fill me-2"></i>
                            <span>123 Event Street, NY</span>
                        </li>
                    </ul>
                </div>
            </div>
            <hr class="footer-divider my-4">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    <p class="footer-copyright mb-0">
                        &copy; <?php echo date('Y'); ?> <strong>EventPlanner Pro</strong>. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="footer-legal-link me-3">Privacy Policy</a>
                    <span class="text-muted">|</span>
                    <a href="#" class="footer-legal-link ms-3">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Toast Container -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="toastContainer"></div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <!-- Custom JS -->
    <script src="<?php echo getBaseUrl(); ?>/assets/js/main.js"></script>
    
    <!-- Theme Toggle Script - Override -->
    <script>
        (function() {
            'use strict';
            
            // Wait for DOM and ensure this runs after main.js
            window.addEventListener('load', function() {
                console.log('=== Theme Toggle Override Starting ===');
                
                const themeToggle = document.getElementById('themeToggle');
                console.log('Button element:', themeToggle);
                
                if (!themeToggle) {
                    console.error('Theme toggle button not found!');
                    return;
                }
                
                // Remove any existing event listeners by cloning
                const newToggle = themeToggle.cloneNode(true);
                themeToggle.parentNode.replaceChild(newToggle, themeToggle);
                
                // Set initial icon based on current theme
                const isDarkMode = document.body.classList.contains('dark-mode');
                console.log('Initial dark mode:', isDarkMode);
                
                newToggle.innerHTML = isDarkMode 
                    ? '<i class="bi bi-sun-fill"></i>' 
                    : '<i class="bi bi-moon-stars-fill"></i>';
                
                // Apply navbar colors on page load if dark mode is active
                if (isDarkMode) {
                    const navbar = document.querySelector('.navbar-professional');
                    if (navbar) {
                        navbar.style.background = 'rgba(26, 26, 46, 0.98)';
                        navbar.style.borderBottom = '2px solid rgba(102, 126, 234, 0.3)';
                    }
                    document.querySelectorAll('.nav-link-professional').forEach(link => {
                        link.style.color = '#b8c1d9';
                    });
                    const brandText = document.querySelector('.brand-text');
                    if (brandText) brandText.style.color = '#ffffff';
                }
                
                // Add new click handler
                newToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    console.log('=== THEME TOGGLE CLICKED ===');
                    
                    // Toggle dark mode
                    const willBeDark = !document.body.classList.contains('dark-mode');
                    document.body.classList.toggle('dark-mode');
                    
                    console.log('Switching to:', willBeDark ? 'DARK' : 'LIGHT');
                    
                    // Update cookie
                    const theme = willBeDark ? 'dark' : 'light';
                    document.cookie = `theme=${theme}; path=/; max-age=31536000`;
                    
                    // Update icon
                    this.innerHTML = willBeDark 
                        ? '<i class="bi bi-sun-fill"></i>' 
                        : '<i class="bi bi-moon-stars-fill"></i>';
                    
                    // Update navbar
                    const navbar = document.querySelector('.navbar-professional');
                    if (navbar) {
                        if (willBeDark) {
                            navbar.style.background = 'rgba(26, 26, 46, 0.98)';
                            navbar.style.borderBottom = '2px solid rgba(102, 126, 234, 0.3)';
                        } else {
                            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
                            navbar.style.borderBottom = '2px solid rgba(102, 126, 234, 0.15)';
                        }
                    }
                    
                    // Update nav links
                    document.querySelectorAll('.nav-link-professional').forEach(link => {
                        link.style.color = willBeDark ? '#b8c1d9' : '#4a5568';
                    });
                    
                    // Update brand text
                    const brandText = document.querySelector('.brand-text');
                    if (brandText) {
                        brandText.style.color = willBeDark ? '#ffffff' : '#1a1a2e';
                    }
                    
                    console.log('Theme switched successfully!');
                });
                
                console.log('=== Theme Toggle Override Complete ===');
            });
        })();
    </script>
</body>
</html>

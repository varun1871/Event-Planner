<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - EventPlanner Pro' : 'EventPlanner Pro - Book Amazing Events'; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo getBaseUrl(); ?>/assets/css/style.css?v=<?php echo time(); ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo getBaseUrl(); ?>/assets/img/favicon.ico">
    
    <style>
        /* Critical CSS - Professional Navbar v2.0 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html {
            margin: 0 !important;
            padding: 0 !important;
            overflow-x: hidden;
        }
        body {
            margin: 0 !important;
            padding: 0 !important;
            padding-top: 90px !important;
        }
        
        /* Force all navbars to use professional styling */
        nav.navbar,
        .navbar-professional,
        nav.navbar-expand-lg,
        nav.navbar-light {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            z-index: 1030 !important;
            background: linear-gradient(135deg, #ffffff 0%, #fafbff 100%) !important;
            box-shadow: 0 4px 24px rgba(102, 126, 234, 0.12) !important;
            padding: 1rem 0 !important;
            border-bottom: 2px solid rgba(102, 126, 234, 0.15) !important;
            backdrop-filter: blur(15px) saturate(180%) !important;
            margin: 0 !important;
        }
        
        .navbar-brand,
        .navbar-brand-professional {
            display: flex !important;
            align-items: center !important;
            gap: 14px !important;
        }
        
        .brand-icon-wrapper {
            width: 48px !important;
            height: 48px !important;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            border-radius: 14px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35) !important;
        }
        
        .brand-icon-wrapper i {
            color: white !important;
            font-size: 1.6rem !important;
        }
        
        .brand-text {
            font-size: 1.5rem !important;
            font-weight: 700 !important;
            color: #1a1a2e !important;
        }
        
        .nav-link,
        .nav-link-professional {
            padding: 12px 20px !important;
            font-size: 1rem !important;
            border-radius: 12px !important;
            margin: 0 4px !important;
        }
        
        button.nav-link,
        .nav-icon-btn {
            width: 44px !important;
            height: 44px !important;
            border-radius: 12px !important;
            background: rgba(102, 126, 234, 0.1) !important;
            color: #667eea !important;
            border: none !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }
        
        .btn-primary.btn-sm,
        .btn-signup {
            padding: 12px 28px !important;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            border: none !important;
            border-radius: 12px !important;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35) !important;
        }
    </style>
    
    <!-- Immediate Theme Application -->
    <script>
        (function() {
            // Get cookie value
            function getCookie(name) {
                const value = `; ${document.cookie}`;
                const parts = value.split(`; ${name}=`);
                if (parts.length === 2) return parts.pop().split(';').shift();
            }
            
            // Apply dark mode immediately if cookie is set
            const theme = getCookie('theme');
            if (theme === 'dark') {
                // Add to both html and body to ensure it works
                document.addEventListener('DOMContentLoaded', function() {
                    document.body.classList.add('dark-mode');
                });
            }
        })();
    </script>
</head>
<body class="<?php echo isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark-mode' : ''; ?>" style="margin: 0 !important; padding: 0 !important; margin-top: 0 !important; padding-top: 90px !important;">

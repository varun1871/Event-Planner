<style>
    .admin-navbar {
        background-color: #2d3748 !important;
        background: #2d3748 !important;
    }
    .admin-navbar .navbar-brand,
    .admin-navbar .nav-link {
        color: #ffffff !important;
    }
    .admin-navbar .nav-link:hover {
        color: #667eea !important;
    }
    body.dark-mode .admin-navbar {
        background-color: #1a1a2e !important;
    }
    /* Force colors even with Dark Reader */
    .admin-navbar * {
        color: #ffffff !important;
    }
</style>
<nav class="navbar navbar-expand-lg shadow-sm sticky-top admin-navbar" style="background: #2d3748 !important; background-color: #2d3748 !important;" data-darkreader-inline-bgcolor="" data-darkreader-inline-bgimage="">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<?php echo getBaseUrl(); ?>/admin/admin_dashboard.php" style="color: #ffffff !important;">
            <i class="bi bi-shield-check"></i> Admin Panel
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav" style="border-color: rgba(255,255,255,0.5);">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="adminNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/admin_dashboard.php" style="color: #ffffff !important;">
                        <i class="bi bi-speedometer2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/manage_users.php" style="color: #ffffff !important;">
                        <i class="bi bi-people"></i> Users
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/manage_organizers.php" style="color: #ffffff !important;">
                        <i class="bi bi-briefcase"></i> Organizers
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/manage_events.php" style="color: #ffffff !important;">
                        <i class="bi bi-calendar3"></i> Events
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/manage_categories.php" style="color: #ffffff !important;">
                        <i class="bi bi-tags"></i> Categories
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/settings.php" style="color: #ffffff !important;">
                        <i class="bi bi-gear"></i> Settings
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/admin/logs.php" style="color: #ffffff !important;">
                        <i class="bi bi-journal-text"></i> Logs
                    </a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo getBaseUrl(); ?>/index.php" target="_blank" style="color: #ffffff !important;">
                        <i class="bi bi-box-arrow-up-right"></i> View Site
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" style="color: #ffffff !important;">
                        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item text-danger" href="<?php echo getBaseUrl(); ?>/auth/logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

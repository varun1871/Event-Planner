<nav class="navbar navbar-expand-lg navbar-professional sticky-top" style="position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; width: 100% !important; z-index: 1030 !important; background: linear-gradient(135deg, #ffffff 0%, #fafbff 100%) !important; box-shadow: 0 4px 24px rgba(102, 126, 234, 0.12) !important; padding: 1rem 0 !important; border-bottom: 2px solid rgba(102, 126, 234, 0.15) !important; backdrop-filter: blur(15px) saturate(180%) !important; margin: 0 !important;">
    <div class="container">
        <!-- Brand Logo -->
        <a class="navbar-brand-professional" href="<?php echo getBaseUrl(); ?>/index.php" style="display: flex !important; align-items: center !important; gap: 14px !important; text-decoration: none !important; padding: 4px 0 !important; cursor: pointer !important; transition: transform 0.2s ease !important;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
            <div class="brand-icon-wrapper" style="width: 48px !important; height: 48px !important; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; border-radius: 14px !important; display: flex !important; align-items: center !important; justify-content: center !important; box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35) !important;">
                <i class="bi bi-calendar-event" style="color: white !important; font-size: 1.6rem !important;"></i>
            </div>
            <span class="brand-text" style="font-size: 1.5rem !important; font-weight: 700 !important; color: #1a1a2e !important; line-height: 1.2 !important; letter-spacing: -0.5px !important;">EventPlanner <span class="brand-pro" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; -webkit-background-clip: text !important; -webkit-text-fill-color: transparent !important; background-clip: text !important; font-weight: 800 !important;">Pro</span></span>
        </a>

        <!-- Mobile Toggle Button -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <!-- Center Navigation -->
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link-professional" href="<?php echo getBaseUrl(); ?>/index.php" style="display: flex !important; align-items: center !important; gap: 10px !important; padding: 12px 20px !important; font-size: 1rem !important; border-radius: 12px !important; margin: 0 4px !important; color: #4a5568 !important; text-decoration: none !important; font-weight: 500 !important;">
                        <i class="bi bi-house-door" style="font-size: 1.15rem !important;"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-professional" href="<?php echo getBaseUrl(); ?>/events/events.php" style="display: flex !important; align-items: center !important; gap: 10px !important; padding: 12px 20px !important; font-size: 1rem !important; border-radius: 12px !important; margin: 0 4px !important; color: #4a5568 !important; text-decoration: none !important; font-weight: 500 !important;">
                        <i class="bi bi-calendar3" style="font-size: 1.15rem !important;"></i>
                        <span>Events</span>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link-professional dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" style="display: flex !important; align-items: center !important; gap: 10px !important; padding: 12px 20px !important; font-size: 1rem !important; border-radius: 12px !important; margin: 0 4px !important; color: #4a5568 !important; text-decoration: none !important; font-weight: 500 !important;">
                        <i class="bi bi-grid-3x3-gap" style="font-size: 1.15rem !important;"></i>
                        <span>Categories</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-modern">
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/events/events.php?category=music">
                            <i class="bi bi-music-note text-primary"></i> Music & Concerts
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/events/events.php?category=sports">
                            <i class="bi bi-trophy text-success"></i> Sports & Fitness
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/events/events.php?category=business">
                            <i class="bi bi-briefcase text-info"></i> Business
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/events/events.php?category=arts">
                            <i class="bi bi-palette text-warning"></i> Arts & Culture
                        </a></li>
                    </ul>
                </li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'organizer'): ?>
                <li class="nav-item">
                    <a class="nav-link-professional" href="<?php echo getBaseUrl(); ?>/organizer/organizer_dashboard.php" style="display: flex !important; align-items: center !important; gap: 10px !important; padding: 12px 20px !important; font-size: 1rem !important; border-radius: 12px !important; margin: 0 4px !important; color: #4a5568 !important; text-decoration: none !important; font-weight: 500 !important;">
                        <i class="bi bi-speedometer2" style="font-size: 1.15rem !important;"></i>
                        <span>Organizer</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>

            <!-- Right Side Actions -->
            <ul class="navbar-nav align-items-center">
                <!-- Search Button -->
                <li class="nav-item">
                    <button class="nav-icon-btn" data-bs-toggle="modal" data-bs-target="#searchModal" title="Search Events" style="width: 44px !important; height: 44px !important; border-radius: 12px !important; background: rgba(102, 126, 234, 0.1) !important; color: #667eea !important; border: none !important; display: flex !important; align-items: center !important; justify-content: center !important; margin: 0 6px !important; font-size: 1.25rem !important;">
                        <i class="bi bi-search"></i>
                    </button>
                </li>

                <!-- Theme Toggle -->
                <li class="nav-item">
                    <button class="nav-icon-btn" id="themeToggle" title="Toggle Theme" style="width: 44px !important; height: 44px !important; border-radius: 12px !important; background: rgba(102, 126, 234, 0.1) !important; color: #667eea !important; border: none !important; display: flex !important; align-items: center !important; justify-content: center !important; margin: 0 6px !important; font-size: 1.25rem !important;">
                        <i class="bi bi-moon-stars"></i>
                    </button>
                </li>
                
                <?php if (is_logged_in()): ?>
                <!-- Notifications -->
                <li class="nav-item dropdown">
                    <button class="nav-icon-btn position-relative" data-bs-toggle="dropdown">
                        <i class="bi bi-bell"></i>
                        <span class="notification-badge">3</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-modern dropdown-menu-end notification-dropdown">
                        <li class="dropdown-header">
                            <strong>Notifications</strong>
                            <span class="badge bg-primary rounded-pill">3</span>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item notification-item" href="#">
                            <i class="bi bi-ticket-perforated text-success"></i>
                            <div>
                                <strong>Booking Confirmed</strong>
                                <small class="d-block text-muted">Your ticket for Summer Music Fest</small>
                            </div>
                        </a></li>
                        <li><a class="dropdown-item notification-item" href="#">
                            <i class="bi bi-star text-warning"></i>
                            <div>
                                <strong>New Event</strong>
                                <small class="d-block text-muted">Tech Conference 2025 is now live</small>
                            </div>
                        </a></li>
                        <li><a class="dropdown-item notification-item" href="#">
                            <i class="bi bi-gift text-danger"></i>
                            <div>
                                <strong>Special Offer</strong>
                                <small class="d-block text-muted">Get 20% off on your next booking</small>
                            </div>
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-center text-primary" href="#">View All Notifications</a></li>
                    </ul>
                </li>

                <!-- Cart -->
                <li class="nav-item">
                    <a class="nav-icon-btn position-relative" href="<?php echo getBaseUrl(); ?>/cart/cart.php" title="Shopping Cart">
                        <i class="bi bi-cart3"></i>
                        <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                        <span class="cart-badge" id="cartCount">
                            <?php echo count($_SESSION['cart']); ?>
                        </span>
                        <?php endif; ?>
                    </a>
                </li>
                
                <!-- User Dropdown -->
                <li class="nav-item dropdown">
                    <a class="user-profile-btn dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                        <div class="user-avatar">
                            <i class="bi bi-person-circle"></i>
                        </div>
                        <span class="user-name d-none d-lg-inline"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-modern dropdown-menu-end">
                        <li class="dropdown-header">
                            <div class="user-info">
                                <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong>
                                <small class="d-block text-muted"><?php echo htmlspecialchars($_SESSION['email']); ?></small>
                            </div>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/user/dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/user/bookings.php">
                            <i class="bi bi-ticket-perforated"></i> My Bookings
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/user/wishlist.php">
                            <i class="bi bi-heart"></i> Wishlist
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo getBaseUrl(); ?>/user/profile.php">
                            <i class="bi bi-person"></i> Profile Settings
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?php echo getBaseUrl(); ?>/auth/logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a></li>
                    </ul>
                </li>
                <?php else: ?>
                <!-- Guest Actions -->
                <li class="nav-item">
                    <a class="btn-login" href="<?php echo getBaseUrl(); ?>/auth/login.php" style="display: flex !important; align-items: center !important; gap: 8px !important; padding: 12px 24px !important; color: #667eea !important; font-weight: 600 !important; font-size: 0.95rem !important; text-decoration: none !important; border-radius: 12px !important; margin-right: 10px !important;">
                        <i class="bi bi-box-arrow-in-right"></i>
                        <span>Login</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="btn-signup" href="<?php echo getBaseUrl(); ?>/auth/register.php" style="display: flex !important; align-items: center !important; gap: 8px !important; padding: 12px 28px !important; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; color: white !important; font-weight: 600 !important; font-size: 0.95rem !important; text-decoration: none !important; border-radius: 12px !important; box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35) !important; border: none !important;">
                        <i class="bi bi-person-plus"></i>
                        <span>Sign Up</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Quick Search Modal -->
<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content search-modal">
            <div class="modal-body p-4">
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal"></button>
                <h5 class="mb-4"><i class="bi bi-search me-2"></i>Quick Search</h5>
                <form action="<?php echo getBaseUrl(); ?>/events/events.php" method="GET">
                    <div class="input-group input-group-lg mb-3">
                        <span class="input-group-text bg-light border-0">
                            <i class="bi bi-search"></i>
                        </span>
                        <input type="text" class="form-control border-0" name="search" placeholder="Search events..." autofocus>
                    </div>
                    <div class="d-flex gap-2 flex-wrap">
                        <span class="badge bg-light text-dark">Music</span>
                        <span class="badge bg-light text-dark">Sports</span>
                        <span class="badge bg-light text-dark">Business</span>
                        <span class="badge bg-light text-dark">Arts</span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Event card component - expects $event array to be available
$images = !empty($event['images']) ? explode(',', $event['images']) : [];
$first_image = !empty($images) ? trim($images[0]) : 'assets/img/default-event.jpg';
$avg_rating = isset($event['avg_rating']) ? round($event['avg_rating'], 1) : 0;
$review_count = isset($event['review_count']) ? $event['review_count'] : 0;
?>

<div class="card event-card h-100 shadow-sm hover-lift">
    <div class="position-relative">
        <img src="<?php echo htmlspecialchars($first_image); ?>" 
             class="card-img-top event-image" 
             alt="<?php echo htmlspecialchars($event['title']); ?>"
             onerror="this.src='assets/img/default-event.jpg'">
        <span class="badge bg-primary position-absolute top-0 start-0 m-2">
            <?php echo htmlspecialchars($event['category_name']); ?>
        </span>
        <?php if (is_logged_in()): ?>
        <button class="btn btn-light btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" 
                data-event-id="<?php echo $event['id']; ?>">
            <i class="bi bi-heart"></i>
        </button>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <h5 class="card-title">
            <a href="<?php echo getBaseUrl(); ?>/events/event_detail.php?id=<?php echo $event['id']; ?>" 
               class="text-decoration-none text-dark">
                <?php echo htmlspecialchars($event['title']); ?>
            </a>
        </h5>
        <p class="card-text text-muted small">
            <i class="bi bi-calendar3"></i> <?php echo format_date($event['event_date']); ?> 
            at <?php echo format_time($event['event_time']); ?>
        </p>
        <p class="card-text text-muted small">
            <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($event['city']); ?>, 
            <?php echo htmlspecialchars($event['venue']); ?>
        </p>
        
        <?php if ($avg_rating > 0): ?>
        <div class="mb-2">
            <span class="text-warning">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <i class="bi bi-star<?php echo $i <= $avg_rating ? '-fill' : ''; ?>"></i>
                <?php endfor; ?>
            </span>
            <small class="text-muted">(<?php echo $review_count; ?> reviews)</small>
        </div>
        <?php endif; ?>
        
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h5 class="text-primary mb-0"><?php echo format_currency($event['price']); ?></h5>
                <small class="text-muted"><?php echo $event['available_seats']; ?> seats left</small>
            </div>
            <a href="<?php echo getBaseUrl(); ?>/events/event_detail.php?id=<?php echo $event['id']; ?>" 
               class="btn btn-primary btn-sm">
                View Details
            </a>
        </div>
    </div>
</div>

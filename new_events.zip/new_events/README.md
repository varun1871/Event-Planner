# 🎫 EventPlanner Pro - Online Event Planner & Ticket Booking System

A complete, professional event planning and ticket booking platform built with **pure PHP and MySQL**. Features AI-powered event recommendations, real-time booking management, and comprehensive admin controls.

---

## ✨ Features

### 👥 User Module
- **User Registration & Login** - Secure authentication with password hashing
- **Event Browsing** - Search, filter, and sort events by category, city, date, and price
- **AI Recommendations** - Personalized event suggestions based on user activity
- **Shopping Cart** - Session-based cart system for multiple event bookings
- **Secure Checkout** - Simulated payment processing
- **Digital Tickets** - Downloadable PDF tickets with QR codes
- **User Dashboard** - View bookings, wishlist, and recommendations
- **Wishlist System** - Save favorite events for later
- **Review System** - Rate and review attended events
- **Profile Management** - Update personal information and password

### 🏢 Organizer Module
- **Organizer Registration** - Apply to become an event organizer
- **Event Management** - Create, edit, and manage events
- **Booking Analytics** - View bookings and revenue statistics
- **Attendee Management** - Check-in tracking and attendee lists
- **CSV Export** - Export attendee data for external use
- **Event Analytics** - Visual charts showing event performance
- **Multi-event Dashboard** - Manage multiple events from one place

### 🛡️ Admin Module
- **Admin Dashboard** - Comprehensive system overview with charts
- **User Management** - Activate/deactivate user accounts
- **Organizer Approval** - Review and approve organizer applications
- **Event Moderation** - Publish, unpublish, or delete events
- **Category Management** - Add and manage event categories
- **System Logs** - Track all user and system activities
- **Revenue Analytics** - Monitor platform revenue and trends

### 🤖 AI Recommendation Engine
- **Pure PHP Implementation** - No external AI APIs required
- **Activity Tracking** - Monitors user searches, views, bookings, and wishlist
- **Smart Scoring** - Calculates event scores based on:
  - Category similarity (50%)
  - Collaborative filtering (30%)
  - Popularity metrics (20%)
- **Personalized Suggestions** - "Recommended For You" section
- **Similar Events** - Find events similar to what you're viewing
- **Trending Detection** - Identify hot events based on recent activity

---

## 🚀 Installation Guide

### Prerequisites
- **XAMPP** (Apache + MySQL + PHP 7.4+)
- Web browser (Chrome, Firefox, Edge, etc.)

### Step 1: Setup Database
1. Start **XAMPP Control Panel**
2. Start **Apache** and **MySQL** services
3. Open **phpMyAdmin** (http://localhost/phpmyadmin)
4. Click "Import" tab
5. Choose file: `eventplanner.sql`
6. Click "Go" to import the database

### Step 2: Configure Application
1. Copy the `new_events` folder to `C:\xampp\htdocs\`
2. Open `config/db.php` and verify database credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'eventplanner');
   ```

### Step 3: Access the Application
1. Open your browser
2. Navigate to: `http://localhost/new_events/`
3. The homepage should load successfully!

---

## 🔐 Default Login Credentials

### Admin Account
- **Email:** admin@eventplanner.com
- **Password:** admin123

### Test User Account
Register a new user or create one via phpMyAdmin.

---

## 📁 Project Structure

```
new_events/
├── admin/                      # Admin panel files
│   ├── admin_dashboard.php     # Admin dashboard with analytics
│   ├── manage_users.php        # User management
│   ├── manage_organizers.php   # Organizer approval
│   ├── manage_events.php       # Event moderation
│   ├── manage_categories.php   # Category management
│   ├── settings.php            # System settings
│   └── logs.php                # Activity logs
│
├── assets/                     # Static assets
│   ├── css/
│   │   └── style.css          # Custom styles
│   ├── js/
│   │   └── main.js            # JavaScript functions
│   └── img/                   # Images
│
├── auth/                       # Authentication
│   ├── login.php              # Login page
│   ├── register.php           # Registration page
│   └── logout.php             # Logout handler
│
├── cart/                       # Shopping cart
│   ├── cart.php               # Cart view
│   ├── checkout.php           # Checkout process
│   ├── success.php            # Success page
│   ├── add_to_cart.php        # Add to cart handler
│   └── get_cart_count.php     # AJAX cart count
│
├── config/
│   └── db.php                 # Database configuration
│
├── events/                     # Event pages
│   ├── events.php             # Event listing with filters
│   └── event_detail.php       # Event details page
│
├── includes/                   # Reusable components
│   ├── header.php             # HTML header
│   ├── footer.php             # HTML footer
│   ├── navbar_user.php        # User navigation
│   ├── navbar_admin.php       # Admin navigation
│   ├── navbar_organizer.php   # Organizer navigation
│   ├── event_card.php         # Event card component
│   └── ai_engine.php          # AI recommendation engine
│
├── organizer/                  # Organizer panel
│   ├── organizer_dashboard.php # Organizer dashboard
│   ├── add_event.php          # Create new event
│   ├── edit_event.php         # Edit event
│   ├── my_events.php          # List all events
│   ├── view_bookings.php      # View event bookings
│   └── export_attendees.php   # Export attendee CSV
│
├── ticket/
│   └── download_ticket.php    # Generate PDF ticket
│
├── user/                       # User panel
│   ├── dashboard.php          # User dashboard
│   ├── bookings.php           # User bookings
│   ├── wishlist.php           # User wishlist
│   ├── profile.php            # Profile management
│   ├── submit_review.php      # Submit review
│   └── toggle_wishlist.php    # AJAX wishlist toggle
│
├── index.php                   # Homepage
├── eventplanner.sql           # Database schema
└── README.md                  # This file
```

---

## 🎨 Technologies Used

### Backend
- **PHP 7.4+** - Server-side logic
- **MySQL** - Database management
- **Session Management** - User authentication

### Frontend
- **Bootstrap 5** - Responsive UI framework
- **Bootstrap Icons** - Icon library
- **Vanilla JavaScript** - Client-side interactions
- **Chart.js** - Data visualization

### Features
- **AJAX** - Asynchronous requests
- **CSS3** - Modern styling with animations
- **Responsive Design** - Mobile-friendly layouts

---

## 🔧 Key Features Explained

### AI Recommendation System
The AI engine uses a scoring algorithm:
```php
final_score = (category_similarity * 0.5) + 
              (collaborative_match * 0.3) + 
              (popularity_score * 0.2)
```

**Tracks:**
- User search queries
- Event views
- Wishlist additions
- Booking history

**Generates:**
- Personalized recommendations
- Similar event suggestions
- Trending events list

### Security Features
- ✅ Password hashing with `password_hash()`
- ✅ SQL injection prevention with prepared statements
- ✅ XSS protection with `htmlspecialchars()`
- ✅ CSRF protection via session validation
- ✅ Input sanitization
- ✅ Role-based access control

### Performance Optimizations
- Efficient database queries with indexes
- Session-based cart (no database overhead)
- Lazy loading for images
- Pagination for large datasets
- Optimized AI scoring with caching

---

## 📊 Database Schema

### Main Tables
- **users** - User accounts (user, admin, organizer)
- **organizers** - Organizer profiles and approval status
- **categories** - Event categories
- **events** - Event listings
- **bookings** - Ticket bookings
- **wishlist** - User wishlists
- **reviews** - Event reviews and ratings
- **logs** - System activity logs
- **ai_user_activity** - AI tracking data
- **ai_event_scores** - AI scoring data
- **settings** - System configuration

---

## 🎯 Usage Guide

### For Users
1. **Register** an account or login
2. **Browse events** using search and filters
3. **Add events** to cart or wishlist
4. **Checkout** and complete booking
5. **Download tickets** from dashboard
6. **Review events** after attending

### For Organizers
1. **Register** as an organizer
2. Wait for **admin approval**
3. **Create events** with details
4. **Manage bookings** and attendees
5. **Export attendee lists** as CSV
6. **Track analytics** and revenue

### For Admins
1. **Login** with admin credentials
2. **Approve organizers** from pending list
3. **Moderate events** (publish/unpublish)
4. **Manage users** and categories
5. **Monitor logs** and activities
6. **View analytics** and reports

---

## 🐛 Troubleshooting

### Database Connection Error
- Verify MySQL is running in XAMPP
- Check database credentials in `config/db.php`
- Ensure database `eventplanner` exists

### Page Not Found (404)
- Check that files are in `C:\xampp\htdocs\new_events\`
- Verify Apache is running
- Clear browser cache

### Login Issues
- Use correct credentials (admin@eventplanner.com / admin123)
- Check if user status is 'active' in database
- Clear browser cookies

### Images Not Loading
- Ensure image URLs are valid
- Check file permissions
- Use absolute URLs for external images

---

## 🌟 Future Enhancements

- Real payment gateway integration (Stripe, PayPal)
- Email notifications for bookings
- SMS reminders for events
- Social media integration
- Mobile app (React Native)
- Advanced analytics dashboard
- Multi-language support
- Event calendar view
- Live chat support
- Promotional codes/discounts

---

## 📝 License

This project is created for educational purposes. Feel free to use and modify as needed.

---

## 👨‍💻 Developer Notes

### Adding New Categories
1. Go to Admin Panel → Manage Categories
2. Click "Add Category"
3. Enter name and Bootstrap icon name
4. Submit

### Creating Sample Events
1. Register as organizer
2. Wait for admin approval
3. Create events with sample data
4. Use image URLs from Unsplash or Pexels

### Testing AI Recommendations
1. Create multiple user accounts
2. Browse different event categories
3. Add events to wishlist
4. Book some events
5. Check dashboard for recommendations

---

## 🆘 Support

For issues or questions:
1. Check the troubleshooting section
2. Review database schema
3. Verify XAMPP configuration
4. Check PHP error logs in `C:\xampp\php\logs\`

---

## 🎉 Credits

- **Bootstrap** - UI Framework
- **Bootstrap Icons** - Icon Library
- **Chart.js** - Data Visualization
- **PHP** - Backend Language
- **MySQL** - Database System

---

**Built with ❤️ using Pure PHP & MySQL**

**No frameworks, no npm, no complexity - just clean, efficient code!**

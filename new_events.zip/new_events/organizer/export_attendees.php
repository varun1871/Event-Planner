<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('organizer')) {
    redirect('../auth/login.php');
}

$event_id = isset($_GET['event_id']) ? (int)$_GET['event_id'] : 0;

// Get organizer ID
$org_query = mysqli_query($conn, "SELECT id FROM organizers WHERE user_id = " . $_SESSION['user_id']);
$organizer = mysqli_fetch_assoc($org_query);
$organizer_id = $organizer['id'];

// Verify event ownership
$event_query = "SELECT title FROM events WHERE id = ? AND organizer_id = ?";
$stmt = mysqli_prepare($conn, $event_query);
mysqli_stmt_bind_param($stmt, "ii", $event_id, $organizer_id);
mysqli_stmt_execute($stmt);
$event = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$event) {
    die('Unauthorized access');
}

// Get bookings
$bookings_query = "SELECT b.booking_code, u.name, u.email, b.qty, b.total_price, b.status, b.checked_in, b.created_at
                   FROM bookings b
                   JOIN users u ON b.user_id = u.id
                   WHERE b.event_id = ?
                   ORDER BY b.created_at DESC";
$stmt = mysqli_prepare($conn, $bookings_query);
mysqli_stmt_bind_param($stmt, "i", $event_id);
mysqli_stmt_execute($stmt);
$bookings_result = mysqli_stmt_get_result($stmt);

// Set headers for CSV download
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="attendees_' . preg_replace('/[^a-z0-9]/i', '_', $event['title']) . '_' . date('Y-m-d') . '.csv"');

// Output CSV
$output = fopen('php://output', 'w');

// CSV Headers
fputcsv($output, ['Booking Code', 'Name', 'Email', 'Tickets', 'Amount', 'Status', 'Checked In', 'Booking Date']);

// CSV Data
while ($booking = mysqli_fetch_assoc($bookings_result)) {
    fputcsv($output, [
        $booking['booking_code'],
        $booking['name'],
        $booking['email'],
        $booking['qty'],
        '$' . number_format($booking['total_price'], 2),
        ucfirst($booking['status']),
        $booking['checked_in'] ? 'Yes' : 'No',
        date('Y-m-d H:i:s', strtotime($booking['created_at']))
    ]);
}

fclose($output);
exit;
?>

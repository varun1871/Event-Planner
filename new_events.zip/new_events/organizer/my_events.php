<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('organizer')) {
    redirect('../auth/login.php');
}

$page_title = 'My Events';
$success = '';
$error = '';

// Get organizer ID
$org_query = mysqli_query($conn, "SELECT id FROM organizers WHERE user_id = " . $_SESSION['user_id']);
$organizer = mysqli_fetch_assoc($org_query);
$organizer_id = $organizer['id'];

// Handle delete request
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $event_id = (int)$_GET['id'];
    
    // Verify event belongs to this organizer
    $check_query = "SELECT id, title FROM events WHERE id = ? AND organizer_id = ?";
    $stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($stmt, "ii", $event_id, $organizer_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($event = mysqli_fetch_assoc($result)) {
        // Check if event has bookings
        $booking_check = mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings WHERE event_id = $event_id");
        $booking_count = mysqli_fetch_assoc($booking_check)['count'];
        
        if ($booking_count > 0) {
            $error = "Cannot delete event with existing bookings. Cancel the event instead.";
        } else {
            // Delete the event
            $delete_query = "DELETE FROM events WHERE id = ? AND organizer_id = ?";
            $delete_stmt = mysqli_prepare($conn, $delete_query);
            mysqli_stmt_bind_param($delete_stmt, "ii", $event_id, $organizer_id);
            
            if (mysqli_stmt_execute($delete_stmt)) {
                log_activity($_SESSION['user_id'], 'Event Deleted', "Deleted event: {$event['title']}");
                $success = "Event deleted successfully!";
            } else {
                $error = "Failed to delete event. Please try again.";
            }
            mysqli_stmt_close($delete_stmt);
        }
    } else {
        $error = "Event not found or you don't have permission to delete it.";
    }
    mysqli_stmt_close($stmt);
}

// Get all events
$events_query = "SELECT e.*, c.name as category_name,
                 (SELECT COUNT(*) FROM bookings WHERE event_id = e.id) as booking_count,
                 e.seats - e.available_seats as sold_tickets
                 FROM events e
                 JOIN categories c ON e.category_id = c.id
                 WHERE e.organizer_id = ?
                 ORDER BY e.event_date DESC";
$stmt = mysqli_prepare($conn, $events_query);
mysqli_stmt_bind_param($stmt, "i", $organizer_id);
mysqli_stmt_execute($stmt);
$events_result = mysqli_stmt_get_result($stmt);

include '../includes/header.php';
include '../includes/navbar_organizer.php';
?>

<div class="container my-5">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-calendar3"></i> My Events</h2>
        </div>
        <div class="col-auto">
            <a href="add_event.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Create New Event
            </a>
        </div>
    </div>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle"></i> <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if (mysqli_num_rows($events_result) > 0): ?>
        <div class="row g-4">
            <?php while ($event = mysqli_fetch_assoc($events_result)): 
                $images = !empty($event['images']) ? explode(',', $event['images']) : [];
                $first_image = !empty($images) ? trim($images[0]) : '../assets/img/default-event.jpg';
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm">
                    <img src="<?php echo htmlspecialchars($first_image); ?>" 
                         class="card-img-top" 
                         style="height: 200px; object-fit: cover;"
                         alt="Event"
                         onerror="this.src='../assets/img/default-event.jpg'">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="badge bg-primary"><?php echo htmlspecialchars($event['category_name']); ?></span>
                            <span class="badge bg-<?php echo $event['status'] === 'published' ? 'success' : 'warning'; ?>">
                                <?php echo ucfirst($event['status']); ?>
                            </span>
                        </div>
                        <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                        <p class="card-text text-muted small">
                            <i class="bi bi-calendar3"></i> <?php echo format_date($event['event_date']); ?><br>
                            <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($event['city']); ?>
                        </p>
                        <hr>
                        <div class="row text-center mb-3">
                            <div class="col-6">
                                <h6 class="mb-0"><?php echo $event['sold_tickets']; ?> / <?php echo $event['seats']; ?></h6>
                                <small class="text-muted">Tickets Sold</small>
                            </div>
                            <div class="col-6">
                                <h6 class="mb-0"><?php echo $event['booking_count']; ?></h6>
                                <small class="text-muted">Bookings</small>
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                            <a href="edit_event.php?id=<?php echo $event['id']; ?>" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-pencil"></i> Edit
                            </a>
                            <a href="view_bookings.php?event_id=<?php echo $event['id']; ?>" class="btn btn-outline-success btn-sm">
                                <i class="bi bi-people"></i> View Bookings
                            </a>
                            <a href="../events/event_detail.php?id=<?php echo $event['id']; ?>" class="btn btn-outline-secondary btn-sm" target="_blank">
                                <i class="bi bi-eye"></i> Preview
                            </a>
                            <a href="?delete=1&id=<?php echo $event['id']; ?>" 
                               class="btn btn-outline-danger btn-sm" 
                               onclick="return confirm('Are you sure you want to delete this event? This action cannot be undone.')">
                                <i class="bi bi-trash"></i> Delete
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-calendar-x text-muted" style="font-size: 5rem;"></i>
            <h3 class="mt-3">No Events Yet</h3>
            <p class="text-muted">Create your first event to get started!</p>
            <a href="add_event.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Create Event
            </a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>

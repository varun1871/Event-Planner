<?php
require_once '../config/db.php';
require_once '../includes/ai_engine.php';

if (!is_logged_in() || !check_role('organizer')) {
    redirect('../auth/login.php');
}

$page_title = 'Edit Event';
$error = '';
$success = '';
$event_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get organizer ID
$org_query = mysqli_query($conn, "SELECT id FROM organizers WHERE user_id = " . $_SESSION['user_id']);
$organizer = mysqli_fetch_assoc($org_query);
$organizer_id = $organizer['id'];

// Get event
$event_query = "SELECT * FROM events WHERE id = ? AND organizer_id = ?";
$stmt = mysqli_prepare($conn, $event_query);
mysqli_stmt_bind_param($stmt, "ii", $event_id, $organizer_id);
mysqli_stmt_execute($stmt);
$event = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$event) {
    redirect('my_events.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean_input($_POST['title']);
    $description = clean_input($_POST['description']);
    $category_id = (int)$_POST['category_id'];
    $city = clean_input($_POST['city']);
    $venue = clean_input($_POST['venue']);
    $event_date = clean_input($_POST['event_date']);
    $event_time = clean_input($_POST['event_time']);
    $price = (float)$_POST['price'];
    $status = clean_input($_POST['status']);
    $images = clean_input($_POST['image_urls']);
    
    if (empty($title) || empty($description)) {
        $error = 'Please fill all required fields.';
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE events SET title = ?, description = ?, category_id = ?, images = ?, city = ?, venue = ?, event_date = ?, event_time = ?, price = ?, status = ? WHERE id = ? AND organizer_id = ?");
        mysqli_stmt_bind_param($stmt, "ssissssdssii", $title, $description, $category_id, $images, $city, $venue, $event_date, $event_time, $price, $status, $event_id, $organizer_id);
        
        if (mysqli_stmt_execute($stmt)) {
            log_activity($_SESSION['user_id'], 'Event Updated', "Updated event: $title");
            update_event_scores($event_id);
            $success = 'Event updated successfully!';
            
            // Refresh event data
            $stmt = mysqli_prepare($conn, "SELECT * FROM events WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $event_id);
            mysqli_stmt_execute($stmt);
            $event = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        } else {
            $error = 'Failed to update event.';
        }
    }
}

// Get categories
$categories_query = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = mysqli_query($conn, $categories_query);

include '../includes/header.php';
include '../includes/navbar_organizer.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="bi bi-pencil"></i> Edit Event</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Event Title *</label>
                                <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Category *</label>
                                <select class="form-select" name="category_id" required>
                                    <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                                        <option value="<?php echo $cat['id']; ?>" <?php echo $event['category_id'] == $cat['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cat['name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description *</label>
                            <textarea class="form-control" name="description" rows="5" required><?php echo htmlspecialchars($event['description']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Event Images (URLs, comma-separated)</label>
                            <input type="text" class="form-control" name="image_urls" value="<?php echo htmlspecialchars($event['images']); ?>">
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City *</label>
                                <input type="text" class="form-control" name="city" value="<?php echo htmlspecialchars($event['city']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Venue *</label>
                                <input type="text" class="form-control" name="venue" value="<?php echo htmlspecialchars($event['venue']); ?>" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Event Date *</label>
                                <input type="date" class="form-control" name="event_date" value="<?php echo $event['event_date']; ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Event Time *</label>
                                <input type="time" class="form-control" name="event_time" value="<?php echo $event['event_time']; ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-select" name="status" required>
                                    <option value="draft" <?php echo $event['status'] == 'draft' ? 'selected' : ''; ?>>Draft</option>
                                    <option value="published" <?php echo $event['status'] == 'published' ? 'selected' : ''; ?>>Published</option>
                                    <option value="cancelled" <?php echo $event['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Ticket Price ($) *</label>
                                <input type="number" class="form-control" name="price" step="0.01" value="<?php echo $event['price']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Total Seats</label>
                                <input type="number" class="form-control" value="<?php echo $event['seats']; ?>" disabled>
                                <small class="text-muted">Cannot change after creation</small>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-2 mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Update Event
                            </button>
                            <a href="my_events.php" class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

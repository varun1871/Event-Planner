<?php
require_once '../config/db.php';
require_once '../includes/ai_engine.php';

if (!is_logged_in() || !check_role('organizer')) {
    redirect('../auth/login.php');
}

$page_title = 'Add Event';
$error = '';
$success = '';

// Get organizer ID
$org_query = mysqli_query($conn, "SELECT id FROM organizers WHERE user_id = " . $_SESSION['user_id']);
$organizer = mysqli_fetch_assoc($org_query);
$organizer_id = $organizer['id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean_input($_POST['title']);
    $description = clean_input($_POST['description']);
    $category_id = (int)$_POST['category_id'];
    $city = clean_input($_POST['city']);
    $venue = clean_input($_POST['venue']);
    $event_date = clean_input($_POST['event_date']);
    $event_time = clean_input($_POST['event_time']);
    $price = (float)$_POST['price'];
    $seats = (int)$_POST['seats'];
    $status = clean_input($_POST['status']);
    
    // Handle image upload (simplified - storing URLs/paths as CSV)
    $images = clean_input($_POST['image_urls']); // For demo, using URLs
    
    if (empty($title) || empty($description) || $category_id <= 0) {
        $error = 'Please fill all required fields.';
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO events (organizer_id, category_id, title, description, images, city, venue, event_date, event_time, price, seats, available_seats, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "iissssssdiiis", $organizer_id, $category_id, $title, $description, $images, $city, $venue, $event_date, $event_time, $price, $seats, $seats, $status);
        
        if (mysqli_stmt_execute($stmt)) {
            $event_id = mysqli_insert_id($conn);
            log_activity($_SESSION['user_id'], 'Event Created', "Created event: $title");
            
            // Initialize AI scores
            update_event_scores($event_id);
            
            $success = 'Event created successfully!';
            header("refresh:2;url=my_events.php");
        } else {
            $error = 'Failed to create event. Please try again.';
        }
        mysqli_stmt_close($stmt);
    }
}

// Get categories
$categories_query = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = mysqli_query($conn, $categories_query);

include '../includes/header.php';
include '../includes/navbar_organizer.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="bi bi-plus-circle"></i> Create New Event</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Event Title *</label>
                                <input type="text" class="form-control" name="title" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Category *</label>
                                <select class="form-select" name="category_id" required>
                                    <option value="">Select Category</option>
                                    <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description *</label>
                            <textarea class="form-control" name="description" rows="5" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Event Images (URLs, comma-separated)</label>
                            <input type="text" class="form-control" name="image_urls" placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg">
                            <small class="text-muted">Enter image URLs separated by commas, or leave blank for default image</small>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City *</label>
                                <input type="text" class="form-control" name="city" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Venue *</label>
                                <input type="text" class="form-control" name="venue" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Event Date *</label>
                                <input type="date" class="form-control" name="event_date" min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Event Time *</label>
                                <input type="time" class="form-control" name="event_time" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-select" name="status" required>
                                    <option value="draft">Draft</option>
                                    <option value="published">Published</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Ticket Price ($) *</label>
                                <input type="number" class="form-control" name="price" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Total Seats *</label>
                                <input type="number" class="form-control" name="seats" min="1" required>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-2 mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle"></i> Create Event
                            </button>
                            <a href="organizer_dashboard.php" class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('organizer')) {
    redirect('../auth/login.php');
}

$page_title = 'Event Bookings';
$event_id = isset($_GET['event_id']) ? (int)$_GET['event_id'] : 0;

// Get organizer ID
$org_query = mysqli_query($conn, "SELECT id FROM organizers WHERE user_id = " . $_SESSION['user_id']);
$organizer = mysqli_fetch_assoc($org_query);
$organizer_id = $organizer['id'];

// Verify event ownership
$event_query = "SELECT * FROM events WHERE id = ? AND organizer_id = ?";
$stmt = mysqli_prepare($conn, $event_query);
mysqli_stmt_bind_param($stmt, "ii", $event_id, $organizer_id);
mysqli_stmt_execute($stmt);
$event = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$event) {
    redirect('my_events.php');
}

// Get bookings
$bookings_query = "SELECT b.*, u.name, u.email
                   FROM bookings b
                   JOIN users u ON b.user_id = u.id
                   WHERE b.event_id = ?
                   ORDER BY b.created_at DESC";
$stmt = mysqli_prepare($conn, $bookings_query);
mysqli_stmt_bind_param($stmt, "i", $event_id);
mysqli_stmt_execute($stmt);
$bookings_result = mysqli_stmt_get_result($stmt);

include '../includes/header.php';
include '../includes/navbar_organizer.php';
?>

<div class="container my-5">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-people"></i> Bookings for: <?php echo htmlspecialchars($event['title']); ?></h2>
            <p class="text-muted">
                <i class="bi bi-calendar3"></i> <?php echo format_date($event['event_date']); ?> at <?php echo format_time($event['event_time']); ?>
            </p>
        </div>
        <div class="col-auto">
            <a href="export_attendees.php?event_id=<?php echo $event_id; ?>" class="btn btn-success">
                <i class="bi bi-download"></i> Export CSV
            </a>
            <a href="my_events.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>
    </div>
    
    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <h3><?php echo mysqli_num_rows($bookings_result); ?></h3>
                    <p class="text-muted mb-0">Total Bookings</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <?php
                    mysqli_data_seek($bookings_result, 0);
                    $total_tickets = 0;
                    while ($b = mysqli_fetch_assoc($bookings_result)) {
                        $total_tickets += $b['qty'];
                    }
                    mysqli_data_seek($bookings_result, 0);
                    ?>
                    <h3><?php echo $total_tickets; ?></h3>
                    <p class="text-muted mb-0">Total Tickets</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <h3><?php echo $event['available_seats']; ?></h3>
                    <p class="text-muted mb-0">Available Seats</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <?php
                    mysqli_data_seek($bookings_result, 0);
                    $total_revenue = 0;
                    while ($b = mysqli_fetch_assoc($bookings_result)) {
                        $total_revenue += $b['total_price'];
                    }
                    mysqli_data_seek($bookings_result, 0);
                    ?>
                    <h3><?php echo format_currency($total_revenue); ?></h3>
                    <p class="text-muted mb-0">Total Revenue</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bookings Table -->
    <div class="card shadow-sm">
        <div class="card-body">
            <?php if (mysqli_num_rows($bookings_result) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Booking Code</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Tickets</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Booked On</th>
                                <th>Check-in</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($booking = mysqli_fetch_assoc($bookings_result)): ?>
                            <tr>
                                <td><code><?php echo $booking['booking_code']; ?></code></td>
                                <td><?php echo htmlspecialchars($booking['name']); ?></td>
                                <td><?php echo htmlspecialchars($booking['email']); ?></td>
                                <td><?php echo $booking['qty']; ?></td>
                                <td><?php echo format_currency($booking['total_price']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $booking['status'] === 'confirmed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($booking['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($booking['created_at'])); ?></td>
                                <td>
                                    <?php if ($booking['checked_in']): ?>
                                        <span class="badge bg-success"><i class="bi bi-check-circle"></i> Checked In</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Not Checked In</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox text-muted" style="font-size: 3rem;"></i>
                    <p class="text-muted mt-3">No bookings yet for this event</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
require_once '../config/db.php';

if (!is_logged_in() || !check_role('organizer')) {
    redirect('../auth/login.php');
}

$page_title = 'Organizer Dashboard';
$user_id = $_SESSION['user_id'];

// Get organizer ID
$org_query = mysqli_query($conn, "SELECT id FROM organizers WHERE user_id = $user_id");
$organizer = mysqli_fetch_assoc($org_query);
$organizer_id = $organizer['id'];

// Get statistics
$stats_query = "SELECT 
                COUNT(DISTINCT e.id) as total_events,
                COUNT(DISTINCT CASE WHEN e.status = 'published' THEN e.id END) as published_events,
                COUNT(DISTINCT b.id) as total_bookings,
                COALESCE(SUM(b.total_price), 0) as total_revenue
                FROM events e
                LEFT JOIN bookings b ON e.id = b.event_id
                WHERE e.organizer_id = $organizer_id";
$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);

// Get upcoming events
$upcoming_query = "SELECT e.*, 
                   (SELECT COUNT(*) FROM bookings WHERE event_id = e.id) as booking_count,
                   e.seats - e.available_seats as sold_tickets
                   FROM events e
                   WHERE e.organizer_id = $organizer_id 
                   AND e.event_date >= CURDATE()
                   ORDER BY e.event_date ASC
                   LIMIT 5";
$upcoming_result = mysqli_query($conn, $upcoming_query);

// Get recent bookings
$bookings_query = "SELECT b.*, e.title, u.name as user_name, u.email as user_email
                   FROM bookings b
                   JOIN events e ON b.event_id = e.id
                   JOIN users u ON b.user_id = u.id
                   WHERE e.organizer_id = $organizer_id
                   ORDER BY b.created_at DESC
                   LIMIT 10";
$bookings_result = mysqli_query($conn, $bookings_query);

include '../includes/header.php';
include '../includes/navbar_organizer.php';
?>

<div class="container my-5">
    <div class="row mb-4">
        <div class="col">
            <h2>Organizer Dashboard</h2>
            <p class="text-muted">Manage your events and track performance</p>
        </div>
        <div class="col-auto">
            <a href="add_event.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Create New Event
            </a>
        </div>
    </div>
    
    <!-- Stats Cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-primary border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Events</h6>
                            <h2 class="mb-0"><?php echo $stats['total_events']; ?></h2>
                        </div>
                        <i class="bi bi-calendar-event text-primary fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-success border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Published</h6>
                            <h2 class="mb-0"><?php echo $stats['published_events']; ?></h2>
                        </div>
                        <i class="bi bi-check-circle text-success fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-warning border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Bookings</h6>
                            <h2 class="mb-0"><?php echo $stats['total_bookings']; ?></h2>
                        </div>
                        <i class="bi bi-ticket-perforated text-warning fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-info border-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Revenue</h6>
                            <h2 class="mb-0"><?php echo format_currency($stats['total_revenue']); ?></h2>
                        </div>
                        <i class="bi bi-currency-dollar text-info fs-1"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Upcoming Events -->
        <div class="col-lg-7 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="bi bi-calendar-check"></i> Upcoming Events</h5>
                        <a href="my_events.php" class="btn btn-sm btn-outline-primary">View All</a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (mysqli_num_rows($upcoming_result) > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php while ($event = mysqli_fetch_assoc($upcoming_result)): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($event['title']); ?></h6>
                                        <small class="text-muted">
                                            <i class="bi bi-calendar3"></i> <?php echo format_date($event['event_date']); ?> 
                                            at <?php echo format_time($event['event_time']); ?>
                                        </small>
                                        <br>
                                        <small class="text-muted">
                                            <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($event['city']); ?>
                                        </small>
                                        <div class="mt-2">
                                            <span class="badge bg-primary"><?php echo $event['sold_tickets']; ?> / <?php echo $event['seats']; ?> sold</span>
                                            <span class="badge bg-success"><?php echo $event['booking_count']; ?> bookings</span>
                                        </div>
                                    </div>
                                    <div class="btn-group">
                                        <a href="edit_event.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="view_bookings.php?event_id=<?php echo $event['id']; ?>" class="btn btn-sm btn-outline-success">
                                            <i class="bi bi-people"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-calendar-x text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-3">No upcoming events</p>
                            <a href="add_event.php" class="btn btn-primary">Create Your First Event</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Recent Bookings -->
        <div class="col-lg-5 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-ticket-perforated"></i> Recent Bookings</h5>
                </div>
                <div class="card-body" style="max-height: 500px; overflow-y: auto;">
                    <?php if (mysqli_num_rows($bookings_result) > 0): ?>
                        <?php while ($booking = mysqli_fetch_assoc($bookings_result)): ?>
                        <div class="mb-3 pb-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <strong><?php echo htmlspecialchars($booking['user_name']); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo htmlspecialchars($booking['title']); ?></small>
                                    <br>
                                    <small class="text-muted">
                                        <?php echo $booking['qty']; ?> tickets - <?php echo format_currency($booking['total_price']); ?>
                                    </small>
                                </div>
                                <small class="text-muted"><?php echo date('M d', strtotime($booking['created_at'])); ?></small>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No bookings yet</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

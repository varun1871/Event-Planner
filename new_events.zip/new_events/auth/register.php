<?php
require_once '../config/db.php';

$page_title = 'Register';
$error = '';
$success = '';

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean_input($_POST['name']);
    $email = clean_input($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = clean_input($_POST['role']);
    $company_name = isset($_POST['company_name']) ? clean_input($_POST['company_name']) : '';
    $phone = isset($_POST['phone']) ? clean_input($_POST['phone']) : '';
    
    // Validation
    if (empty($name) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        // Check if email exists
        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) > 0) {
            $error = 'Email already registered.';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, ?, 'active')");
            mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hashed_password, $role);
            
            if (mysqli_stmt_execute($stmt)) {
                $user_id = mysqli_insert_id($conn);
                
                // If organizer, create organizer record
                if ($role === 'organizer') {
                    $stmt = mysqli_prepare($conn, "INSERT INTO organizers (user_id, company_name, phone, approved) VALUES (?, ?, ?, 'pending')");
                    mysqli_stmt_bind_param($stmt, "iss", $user_id, $company_name, $phone);
                    mysqli_stmt_execute($stmt);
                }
                
                log_activity($user_id, 'User Registration', "New $role registered: $email");
                $success = 'Registration successful! You can now login.';
                
                // Redirect after 2 seconds
                header("refresh:2;url=login.php");
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
        mysqli_stmt_close($stmt);
    }
}

include '../includes/header.php';
?>

<style>
    /* Override header padding for register page */
    body {
        padding-top: 0 !important;
        margin: 0 !important;
        overflow-x: hidden;
    }
    
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }
    
    /* Hide navbar on register page */
    nav.navbar {
        display: none !important;
    }
    
    .register-container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
    }
    
    .register-card {
        background: rgba(255, 255, 255, 0.98);
        border-radius: 15px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        backdrop-filter: blur(10px);
    }
    
    body.dark-mode .register-card {
        background: rgba(26, 26, 46, 0.98);
    }
    
    
    /* Footer positioning */
    footer {
        margin-top: 0 !important;
        position: relative;
        z-index: 10;
    }
    
    /* Wrapper to contain everything */
    .page-wrapper {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        height: 100vh;
        overflow-y: auto;
        background-image: url('https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1920&q=80');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }
    
    .page-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.4);
        z-index: 1;
    }
    
    .page-wrapper > * {
        position: relative;
        z-index: 2;
    }
    
    .register-container {
        background: none !important;
    }
</style>

<div class="page-wrapper">
<div class="register-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="register-card p-5">
                    <div class="text-center mb-4">
                        <i class="bi bi-calendar-event text-primary" style="font-size: 3rem;"></i>
                        <h2 class="mt-3">Create Account</h2>
                        <p class="text-muted">Join EventPlanner Pro today</p>
                    </div>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle"></i> <?php echo $success; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" id="registerForm">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email Address *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="password" id="registerPassword" minlength="6" required>
                                    <span class="input-group-text" style="cursor: pointer;" id="toggleRegisterPassword">
                                        <i class="bi bi-eye"></i>
                                    </span>
                                </div>
                                <small class="text-muted">At least 6 characters</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Confirm Password *</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" name="confirm_password" id="confirmPassword" required>
                                    <span class="input-group-text" style="cursor: pointer;" id="toggleConfirmPassword">
                                        <i class="bi bi-eye"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Register As *</label>
                            <select class="form-select" name="role" id="roleSelect" required>
                                <option value="user">Event Attendee</option>
                                <option value="organizer">Event Organizer</option>
                            </select>
                        </div>
                        
                        <div id="organizerFields" style="display: none;">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Company Name</label>
                                    <input type="text" class="form-control" name="company_name">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" name="phone">
                                </div>
                            </div>
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle"></i> Your organizer account will be reviewed by admin before approval.
                            </div>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="terms" required>
                            <label class="form-check-label" for="terms">
                                I agree to the <a href="#">Terms & Conditions</a>
                            </label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 py-2">
                            <i class="bi bi-person-plus"></i> Create Account
                        </button>
                    </form>
                    
                    <div class="text-center mt-4">
                        <p class="text-muted">Already have an account? <a href="login.php">Login here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('roleSelect').addEventListener('change', function() {
    const organizerFields = document.getElementById('organizerFields');
    if (this.value === 'organizer') {
        organizerFields.style.display = 'block';
    } else {
        organizerFields.style.display = 'none';
    }
});

// Toggle password visibility
document.getElementById('toggleRegisterPassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('registerPassword');
    const icon = this.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
});

// Toggle confirm password visibility
document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('confirmPassword');
    const icon = this.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
});
</script>

<?php include '../includes/footer.php'; ?>
</div><!-- Close page-wrapper -->

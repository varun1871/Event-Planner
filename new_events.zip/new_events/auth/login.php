<?php
require_once '../config/db.php';

$page_title = 'Login';
$error = '';

// Redirect if already logged in
if (is_logged_in()) {
    if (check_role('admin')) {
        redirect('../admin/admin_dashboard.php');
    } elseif (check_role('organizer')) {
        redirect('../organizer/organizer_dashboard.php');
    } else {
        redirect('../user/dashboard.php');
    }
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean_input($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error = 'Please enter email and password.';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT id, name, email, password, role, status FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($user = mysqli_fetch_assoc($result)) {
            if ($user['status'] === 'inactive') {
                $error = 'Your account has been deactivated. Please contact admin.';
            } elseif (password_verify($password, $user['password'])) {
                // Check if organizer is approved
                if ($user['role'] === 'organizer') {
                    $stmt = mysqli_prepare($conn, "SELECT approved FROM organizers WHERE user_id = ?");
                    mysqli_stmt_bind_param($stmt, "i", $user['id']);
                    mysqli_stmt_execute($stmt);
                    $org_result = mysqli_stmt_get_result($stmt);
                    $organizer = mysqli_fetch_assoc($org_result);
                    
                    if ($organizer['approved'] === 'pending') {
                        $error = 'Your organizer account is pending approval.';
                    } elseif ($organizer['approved'] === 'rejected') {
                        $error = 'Your organizer account has been rejected.';
                    } else {
                        // Approved organizer
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_name'] = $user['name'];
                        $_SESSION['user_email'] = $user['email'];
                        $_SESSION['role'] = $user['role'];
                        
                        log_activity($user['id'], 'Login', 'User logged in');
                        redirect('../organizer/organizer_dashboard.php');
                    }
                } else {
                    // Regular user or admin
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    
                    log_activity($user['id'], 'Login', 'User logged in');
                    
                    if ($user['role'] === 'admin') {
                        redirect('../admin/admin_dashboard.php');
                    } else {
                        redirect('../index.php');
                    }
                }
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'Invalid email or password.';
        }
        mysqli_stmt_close($stmt);
    }
}

include '../includes/header.php';
?>

<style>
    /* Override header padding for login page */
    body {
        padding-top: 0 !important;
        margin: 0 !important;
        overflow-x: hidden;
    }
    
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }
    
    /* Hide navbar on login page */
    nav.navbar {
        display: none !important;
    }
    
    .login-container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    .login-card {
        background: rgba(255, 255, 255, 0.98);
        border-radius: 15px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        backdrop-filter: blur(10px);
    }
    
    body.dark-mode .login-card {
        background: rgba(26, 26, 46, 0.98);
    }
    
    
    /* Footer positioning */
    footer {
        margin-top: 0 !important;
        position: relative;
        z-index: 10;
    }
    
    /* Wrapper to contain everything */
    .page-wrapper {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        height: 100vh;
        overflow-y: auto;
        background-image: url('https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1920&q=80');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }
    
    .page-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 1;
    }
    
    .page-wrapper > * {
        position: relative;
        z-index: 2;
    }
    
    .login-container {
        background: none !important;
    }
</style>

<div class="page-wrapper">
<div class="login-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="login-card p-5">
                    <div class="text-center mb-4">
                        <i class="bi bi-calendar-event text-primary" style="font-size: 3rem;"></i>
                        <h2 class="mt-3">Welcome Back</h2>
                        <p class="text-muted">Login to your account</p>
                    </div>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                <input type="password" class="form-control" name="password" id="loginPassword" placeholder="Enter your password" required>
                                <span class="input-group-text" style="cursor: pointer;" id="toggleLoginPassword">
                                    <i class="bi bi-eye"></i>
                                </span>
                            </div>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="remember">
                            <label class="form-check-label" for="remember">Remember me</label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 py-2">
                            <i class="bi bi-box-arrow-in-right"></i> Login
                        </button>
                    </form>
                    
                    <div class="text-center mt-4">
                        <p class="text-muted">Don't have an account? <a href="register.php">Register here</a></p>
                    </div>
                    
                    <hr>
                    
                    <div class="text-center">
                        <small class="text-muted">
                            <strong>Demo Credentials:</strong><br>
                            Admin: admin@eventplanner.com / admin123
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Toggle password visibility
document.getElementById('toggleLoginPassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('loginPassword');
    const icon = this.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('bi-eye');
        icon.classList.add('bi-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('bi-eye-slash');
        icon.classList.add('bi-eye');
    }
});
</script>

<?php include '../includes/footer.php'; ?>
</div><!-- Close page-wrapper -->

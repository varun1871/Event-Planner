<?php
require_once '../config/db.php';
require_once '../includes/ai_engine.php';

$page_title = 'Browse Events';

// Get filters
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$city = isset($_GET['city']) ? clean_input($_GET['city']) : '';
$date = isset($_GET['date']) ? clean_input($_GET['date']) : '';
$sort = isset($_GET['sort']) ? clean_input($_GET['sort']) : 'newest';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Track search activity
if (is_logged_in() && !empty($search)) {
    track_user_activity($_SESSION['user_id'], 'search', null, $category > 0 ? $category : null, $search);
}

// Build query
$where_conditions = ["e.status = 'published'", "e.event_date >= CURDATE()", "e.available_seats > 0"];
$params = [];
$types = '';

if (!empty($search)) {
    $where_conditions[] = "(e.title LIKE ? OR e.description LIKE ? OR c.name LIKE ?)";
    $search_param = "%$search%";
    $params[] = &$search_param;
    $params[] = &$search_param;
    $params[] = &$search_param;
    $types .= 'sss';
}

if ($category > 0) {
    $where_conditions[] = "e.category_id = ?";
    $params[] = &$category;
    $types .= 'i';
}

if (!empty($city)) {
    $where_conditions[] = "e.city LIKE ?";
    $city_param = "%$city%";
    $params[] = &$city_param;
    $types .= 's';
}

if (!empty($date)) {
    $where_conditions[] = "e.event_date = ?";
    $params[] = &$date;
    $types .= 's';
}

$where_clause = implode(' AND ', $where_conditions);

// Sorting
$order_by = match($sort) {
    'price_low' => 'e.price ASC',
    'price_high' => 'e.price DESC',
    'date' => 'e.event_date ASC',
    'popular' => 'e.views DESC',
    'trending' => '(SELECT COUNT(*) FROM bookings WHERE event_id = e.id) DESC',
    default => 'e.created_at DESC'
};

// Get total count
$count_query = "SELECT COUNT(*) as total FROM events e 
                JOIN categories c ON e.category_id = c.id 
                WHERE $where_clause";
$stmt = mysqli_prepare($conn, $count_query);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$count_result = mysqli_stmt_get_result($stmt);
$total_events = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_events / $per_page);

// Get events
$events_query = "SELECT e.*, c.name as category_name, u.name as organizer_name,
                 (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                 (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count
                 FROM events e
                 JOIN categories c ON e.category_id = c.id
                 JOIN organizers o ON e.organizer_id = o.id
                 JOIN users u ON o.user_id = u.id
                 WHERE $where_clause
                 ORDER BY $order_by
                 LIMIT ? OFFSET ?";

$params[] = &$per_page;
$params[] = &$offset;
$types .= 'ii';

$stmt = mysqli_prepare($conn, $events_query);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$events_result = mysqli_stmt_get_result($stmt);

// Get categories for filter
$categories_query = "SELECT * FROM categories ORDER BY name ASC";
$categories_result = mysqli_query($conn, $categories_query);

// Get unique cities
$cities_query = "SELECT DISTINCT city FROM events WHERE status = 'published' ORDER BY city ASC";
$cities_result = mysqli_query($conn, $cities_query);

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <div class="row">
        <!-- Filters Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card shadow-lg sticky-top" style="top: 90px; border-radius: 20px; border: none; overflow: hidden;">
                <div class="card-header text-white" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border: none;">
                    <h5 class="mb-0 fw-bold"><i class="bi bi-funnel-fill me-2"></i>Filters</h5>
                </div>
                <div class="card-body" style="padding: 2rem;">
                    <form method="GET" action="" id="filterForm">
                        <!-- Search -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold mb-2" style="color: #4a5568; font-size: 0.95rem;"><i class="bi bi-search me-2" style="color: #667eea;"></i>Search</label>
                            <input type="text" class="form-control" name="search" 
                                   value="<?php echo htmlspecialchars($search); ?>" 
                                   placeholder="Search events..."
                                   style="border-radius: 12px; padding: 0.875rem; border: 2px solid #e2e8f0; font-size: 0.95rem;">
                        </div>
                        
                        <!-- Category -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold mb-2" style="color: #4a5568; font-size: 0.95rem;"><i class="bi bi-grid-3x3-gap me-2" style="color: #667eea;"></i>Category</label>
                            <select class="form-select" name="category" style="border-radius: 12px; padding: 0.875rem; border: 2px solid #e2e8f0; font-size: 0.95rem;">
                                <option value="">All Categories</option>
                                <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                                    <option value="<?php echo $cat['id']; ?>" 
                                            <?php echo $category == $cat['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <!-- City -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold mb-2" style="color: #4a5568; font-size: 0.95rem;"><i class="bi bi-geo-alt me-2" style="color: #667eea;"></i>City</label>
                            <select class="form-select" name="city" style="border-radius: 12px; padding: 0.875rem; border: 2px solid #e2e8f0; font-size: 0.95rem;">
                                <option value="">All Cities</option>
                                <?php while ($city_row = mysqli_fetch_assoc($cities_result)): ?>
                                    <option value="<?php echo $city_row['city']; ?>" 
                                            <?php echo $city == $city_row['city'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($city_row['city']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <!-- Date -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold mb-2" style="color: #4a5568; font-size: 0.95rem;"><i class="bi bi-calendar-event me-2" style="color: #667eea;"></i>Date</label>
                            <input type="date" class="form-control" name="date" 
                                   value="<?php echo htmlspecialchars($date); ?>" 
                                   min="<?php echo date('Y-m-d'); ?>"
                                   style="border-radius: 12px; padding: 0.875rem; border: 2px solid #e2e8f0; font-size: 0.95rem;">
                        </div>
                        
                        <!-- Sort -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold mb-2" style="color: #4a5568; font-size: 0.95rem;"><i class="bi bi-sort-down me-2" style="color: #667eea;"></i>Sort By</label>
                            <select class="form-select" name="sort" style="border-radius: 12px; padding: 0.875rem; border: 2px solid #e2e8f0; font-size: 0.95rem;">
                                <option value="newest" <?php echo $sort == 'newest' ? 'selected' : ''; ?>>Newest First</option>
                                <option value="date" <?php echo $sort == 'date' ? 'selected' : ''; ?>>Date</option>
                                <option value="price_low" <?php echo $sort == 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                                <option value="price_high" <?php echo $sort == 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                                <option value="popular" <?php echo $sort == 'popular' ? 'selected' : ''; ?>>Most Popular</option>
                                <option value="trending" <?php echo $sort == 'trending' ? 'selected' : ''; ?>>Trending</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 mb-3" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; border-radius: 12px; padding: 1rem; font-weight: 600; box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35); font-size: 1rem; transition: all 0.3s ease;">
                            <i class="bi bi-search me-2"></i>Apply Filters
                        </button>
                        <a href="events.php" class="btn btn-outline-secondary w-100" style="border-radius: 12px; padding: 1rem; font-weight: 600; border-width: 2px; color: #667eea; border-color: #667eea; font-size: 1rem; transition: all 0.3s ease;">
                            <i class="bi bi-x-circle me-2"></i>Clear Filters
                        </a>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Events Grid -->
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4 pb-3" style="border-bottom: 2px solid #e2e8f0;">
                <h2 class="fw-bold" style="color: #1a1a2e; font-size: 2rem; margin: 0;">
                    <?php if (!empty($search)): ?>
                        <i class="bi bi-search me-2" style="color: #667eea;"></i>Search Results for "<?php echo htmlspecialchars($search); ?>"
                    <?php else: ?>
                        <i class="bi bi-calendar-event me-2" style="color: #667eea;"></i>All Events
                    <?php endif; ?>
                </h2>
                <span class="badge" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 0.75rem 1.5rem; border-radius: 50px; font-size: 1rem; font-weight: 600; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);"><?php echo $total_events; ?> events found</span>
            </div>
            
            <?php if (mysqli_num_rows($events_result) > 0): ?>
                <div class="row g-4">
                    <?php while ($event = mysqli_fetch_assoc($events_result)): ?>
                        <div class="col-md-6 col-lg-4">
                            <?php include '../includes/event_card.php'; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <nav class="mt-5">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">
                                    <i class="bi bi-chevron-left"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">
                                    <i class="bi bi-chevron-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-calendar-x text-muted" style="font-size: 4rem;"></i>
                    <h3 class="mt-3">No Events Found</h3>
                    <p class="text-muted">Try adjusting your filters or search criteria</p>
                    <a href="events.php" class="btn btn-primary">View All Events</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
require_once '../config/db.php';
require_once '../includes/ai_engine.php';

$event_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($event_id <= 0) {
    redirect('../events/events.php');
}

// Get event details
$event_query = "SELECT e.*, c.name as category_name, c.id as category_id,
                u.name as organizer_name, u.email as organizer_email, o.company_name,
                (SELECT AVG(rating) FROM reviews WHERE event_id = e.id) as avg_rating,
                (SELECT COUNT(*) FROM reviews WHERE event_id = e.id) as review_count
                FROM events e
                JOIN categories c ON e.category_id = c.id
                JOIN organizers o ON e.organizer_id = o.id
                JOIN users u ON o.user_id = u.id
                WHERE e.id = ? AND e.status = 'published'";

$stmt = mysqli_prepare($conn, $event_query);
mysqli_stmt_bind_param($stmt, "i", $event_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$event = mysqli_fetch_assoc($result);

if (!$event) {
    redirect('../events/events.php');
}

// Update views
mysqli_query($conn, "UPDATE events SET views = views + 1 WHERE id = $event_id");

// Track view activity
if (is_logged_in()) {
    track_user_activity($_SESSION['user_id'], 'view', $event_id, $event['category_id']);
}

// Update event scores
update_event_scores($event_id);

// Get reviews
$reviews_query = "SELECT r.*, u.name as user_name 
                  FROM reviews r
                  JOIN users u ON r.user_id = u.id
                  WHERE r.event_id = ?
                  ORDER BY r.created_at DESC
                  LIMIT 10";
$stmt = mysqli_prepare($conn, $reviews_query);
mysqli_stmt_bind_param($stmt, "i", $event_id);
mysqli_stmt_execute($stmt);
$reviews_result = mysqli_stmt_get_result($stmt);

// Check if user has booked this event
$user_has_booked = false;
$user_has_reviewed = false;
if (is_logged_in()) {
    $stmt = mysqli_prepare($conn, "SELECT id FROM bookings WHERE user_id = ? AND event_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $_SESSION['user_id'], $event_id);
    mysqli_stmt_execute($stmt);
    $user_has_booked = mysqli_stmt_get_result($stmt)->num_rows > 0;
    
    $stmt = mysqli_prepare($conn, "SELECT id FROM reviews WHERE user_id = ? AND event_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $_SESSION['user_id'], $event_id);
    mysqli_stmt_execute($stmt);
    $user_has_reviewed = mysqli_stmt_get_result($stmt)->num_rows > 0;
}

// Get similar events
$similar_events = get_similar_events($event_id, 3);

$page_title = $event['title'];
$images = !empty($event['images']) ? explode(',', $event['images']) : [];

include '../includes/header.php';
include '../includes/navbar_user.php';
?>

<div class="container my-5">
    <div class="row">
        <!-- Event Images -->
        <div class="col-lg-8">
            <div id="eventCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
                <div class="carousel-inner rounded">
                    <?php if (!empty($images)): ?>
                        <?php foreach ($images as $index => $image): ?>
                            <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                <img src="<?php echo htmlspecialchars(trim($image)); ?>" 
                                     class="d-block w-100" 
                                     style="height: 500px; object-fit: cover;"
                                     alt="Event Image"
                                     onerror="this.src='../assets/img/default-event.jpg'">
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="carousel-item active">
                            <img src="../assets/img/default-event.jpg" class="d-block w-100" style="height: 500px; object-fit: cover;" alt="Event">
                        </div>
                    <?php endif; ?>
                </div>
                <?php if (count($images) > 1): ?>
                <button class="carousel-control-prev" type="button" data-bs-target="#eventCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#eventCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </button>
                <?php endif; ?>
            </div>
            
            <!-- Event Details -->
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <span class="badge bg-primary mb-2"><?php echo htmlspecialchars($event['category_name']); ?></span>
                            <h1 class="h2"><?php echo htmlspecialchars($event['title']); ?></h1>
                        </div>
                        <?php if (is_logged_in()): ?>
                        <button class="btn btn-outline-danger wishlist-btn" data-event-id="<?php echo $event_id; ?>">
                            <i class="bi bi-heart"></i> Wishlist
                        </button>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($event['avg_rating'] > 0): ?>
                    <div class="mb-3">
                        <span class="text-warning fs-5">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="bi bi-star<?php echo $i <= round($event['avg_rating']) ? '-fill' : ''; ?>"></i>
                            <?php endfor; ?>
                        </span>
                        <span class="ms-2"><?php echo number_format($event['avg_rating'], 1); ?> (<?php echo $event['review_count']; ?> reviews)</span>
                    </div>
                    <?php endif; ?>
                    
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-calendar3 text-primary fs-4 me-3"></i>
                                <div>
                                    <small class="text-muted d-block">Date & Time</small>
                                    <strong><?php echo format_date($event['event_date']); ?> at <?php echo format_time($event['event_time']); ?></strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-geo-alt text-primary fs-4 me-3"></i>
                                <div>
                                    <small class="text-muted d-block">Location</small>
                                    <strong><?php echo htmlspecialchars($event['venue']); ?>, <?php echo htmlspecialchars($event['city']); ?></strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-person text-primary fs-4 me-3"></i>
                                <div>
                                    <small class="text-muted d-block">Organized By</small>
                                    <strong><?php echo htmlspecialchars($event['company_name'] ?: $event['organizer_name']); ?></strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-ticket-perforated text-primary fs-4 me-3"></i>
                                <div>
                                    <small class="text-muted d-block">Available Seats</small>
                                    <strong><?php echo $event['available_seats']; ?> / <?php echo $event['seats']; ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <h4>About This Event</h4>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
                </div>
            </div>
            
            <!-- Reviews Section -->
            <div class="card shadow-sm">
                <div class="card-header">
                    <h4 class="mb-0"><i class="bi bi-star"></i> Reviews</h4>
                </div>
                <div class="card-body">
                    <?php if ($user_has_booked && !$user_has_reviewed && strtotime($event['event_date']) < time()): ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> You attended this event. Please leave a review!
                        <button class="btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#reviewModal">
                            Write Review
                        </button>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (mysqli_num_rows($reviews_result) > 0): ?>
                        <?php while ($review = mysqli_fetch_assoc($reviews_result)): ?>
                        <div class="mb-3 pb-3 border-bottom">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <strong><?php echo htmlspecialchars($review['user_name']); ?></strong>
                                    <div class="text-warning">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="bi bi-star<?php echo $i <= $review['rating'] ? '-fill' : ''; ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <small class="text-muted"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></small>
                            </div>
                            <p class="mt-2 mb-0"><?php echo htmlspecialchars($review['comment']); ?></p>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No reviews yet. Be the first to review!</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Booking Sidebar -->
        <div class="col-lg-4">
            <div class="card shadow-sm sticky-top" style="top: 80px;">
                <div class="card-body">
                    <h3 class="text-primary mb-3"><?php echo format_currency($event['price']); ?></h3>
                    <p class="text-muted mb-4">per ticket</p>
                    
                    <?php if ($event['available_seats'] > 0): ?>
                        <form action="../cart/add_to_cart.php" method="POST">
                            <input type="hidden" name="event_id" value="<?php echo $event_id; ?>">
                            <div class="mb-3">
                                <label class="form-label">Number of Tickets</label>
                                <input type="number" class="form-control" name="quantity" value="1" min="1" 
                                       max="<?php echo min(10, $event['available_seats']); ?>" required>
                            </div>
                            <?php if (is_logged_in()): ?>
                                <button type="submit" class="btn btn-primary w-100 mb-2">
                                    <i class="bi bi-cart-plus"></i> Add to Cart
                                </button>
                            <?php else: ?>
                                <a href="../auth/login.php" class="btn btn-primary w-100 mb-2">
                                    Login to Book
                                </a>
                            <?php endif; ?>
                        </form>
                    <?php else: ?>
                        <button class="btn btn-secondary w-100" disabled>
                            <i class="bi bi-x-circle"></i> Sold Out
                        </button>
                    <?php endif; ?>
                    
                    <div class="mt-4">
                        <h6>Share This Event</h6>
                        <div class="d-flex gap-2">
                            <a href="#" class="btn btn-outline-primary btn-sm flex-fill">
                                <i class="bi bi-facebook"></i>
                            </a>
                            <a href="#" class="btn btn-outline-info btn-sm flex-fill">
                                <i class="bi bi-twitter"></i>
                            </a>
                            <a href="#" class="btn btn-outline-danger btn-sm flex-fill">
                                <i class="bi bi-envelope"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Similar Events -->
    <?php if (!empty($similar_events)): ?>
    <div class="mt-5">
        <h3 class="mb-4"><i class="bi bi-stars text-warning"></i> Similar Events You Might Like</h3>
        <div class="row g-4">
            <?php foreach ($similar_events as $event): ?>
            <div class="col-md-4">
                <?php include '../includes/event_card.php'; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Review Modal -->
<div class="modal fade" id="reviewModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Write a Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="../user/submit_review.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="event_id" value="<?php echo $event_id; ?>">
                    <div class="mb-3">
                        <label class="form-label">Rating</label>
                        <div class="rating-input">
                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                <input type="radio" name="rating" value="<?php echo $i; ?>" id="star<?php echo $i; ?>" required>
                                <label for="star<?php echo $i; ?>"><i class="bi bi-star-fill"></i></label>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Comment</label>
                        <textarea class="form-control" name="comment" rows="4" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Review</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

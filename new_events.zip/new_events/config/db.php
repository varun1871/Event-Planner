<?php
/**
 * Database Configuration
 * Connection settings for MySQL database
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'eventplanner');

// Create connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset to UTF-8
mysqli_set_charset($conn, "utf8mb4");

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Helper function to sanitize input
 */
function clean_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

/**
 * Helper function to check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Helper function to check user role
 */
function check_role($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

/**
 * Helper function to redirect
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * Helper function to log activity
 */
function log_activity($user_id, $action, $description = null) {
    global $conn;
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $stmt = mysqli_prepare($conn, "INSERT INTO logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "isss", $user_id, $action, $description, $ip_address);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/**
 * Helper function to generate booking code
 */
function generate_booking_code() {
    return 'BK' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 10));
}

/**
 * Helper function to format date
 */
function format_date($date) {
    return date('M d, Y', strtotime($date));
}

/**
 * Helper function to format time
 */
function format_time($time) {
    return date('h:i A', strtotime($time));
}

/**
 * Helper function to format currency
 */
function format_currency($amount) {
    return '₹' . number_format($amount, 2);
}

/**
 * Get base URL for the application
 */
function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    // Get the base path - always return the project root
    // This finds the /new_events part regardless of which subfolder the script is in
    $script_path = $_SERVER['SCRIPT_NAME'];
    // Extract the base path (e.g., /new_events from /new_events/events/events.php)
    if (preg_match('#^(/[^/]+)/#', $script_path, $matches)) {
        $base = $matches[1];
    } else {
        $base = '';
    }
    return $protocol . "://" . $host . $base;
}
?>
